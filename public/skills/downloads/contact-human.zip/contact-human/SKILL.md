---
name: contact-human
description: Securely call a human through Squirrel Brain when an agent needs a decision or intervention, explain the situation with concrete options, poll the MCP Portal for the spoken answer, route that answer back to the owning task, and verify follow-through. Use for unattended agents, supervisor/watchdog loops, blocked automation, approval escalation, or any workflow that must not stop silently when human judgment is required.
---

# Contact Your Human

Close the whole human-in-the-loop cycle: detect intervention, brief clearly, call, listen, route, and verify. Do not treat a delivered call or captured answer as completion.

## Security boundary

- Never place an `sb_` key, bearer token, user name, account id, Portal content, or local state in this skill folder, a repository, a prompt, a command-line argument, a log, or a downloadable package.
- Prefer an already-configured Squirrel Brain MCP connection. The bundled helper accepts credentials only from `SB_API_KEY` and `SB_ANON_JWT` environment variables or the operating-system Keychain.
- Keep host state isolated. `CONTACT_HUMAN_STATE_ROOT` selects a dedicated state directory explicitly; otherwise the helper uses `CLAUDE_CONFIG_DIR` only when `CODEX_HOME` is absent, retaining the existing Codex default. Never point two independent coordinators at the same state root.
- Keep state outside project repositories. The helper enforces mode `0700` on its state directory and `0600` on state files, including repairs under a permissive umask. It claims a dedicated directory with an exact ownership marker and refuses unrelated private JSON or any state path containing a symbolic-link component.
- The helper pins credentials to the production Squirrel Brain HTTPS MCP endpoint. A self-hosted endpoint must be explicitly named in `SB_MCP_TRUSTED_URLS`; validation happens before credentials load.
- Scope Portal reads to the authenticated Squirrel Brain user. Read `agent_name: all` only because voice replies may be stored in the in-app squirrel thread.
- Never claim a reply-capable contact unless `cell_alert` returns `called: true`, `devices_reached >= 1`, `via_voip: true`, and `reply_capable: true`. A delivered one-way fallback is an alert only; record it fail-closed and never poll or rering as though it could capture an answer.

## Setup check

Run a read-only probe before relying on the route:

```bash
python3 scripts/contact_human.py probe
```

If the host already exposes Squirrel Brain MCP tools, use those directly and preserve the same receipt and exact-call correlation rules. Otherwise configure secrets outside the skill:

- `SB_API_KEY`: the user's private `sb_` key from Squirrel Brain Settings.
- `SB_ANON_JWT`: the public client authorization value documented by Squirrel Brain.
- Optional Keychain services: `Squirrel Brain MCP` and `Squirrel Brain MCP Anon`, account `contact-human`.

Do not ask a user to paste a key into chat. If a key is pasted, advise rotation and do not repeat it.

## Intervention trigger

Do not rely on keywords or a human's name. Intervene when safe progress requires human judgment, including:

- a choice, approval, credential, physical action, purchase, personal-data action, irreversible direction, or taste call;
- repeated failure or no artifact progress after a strategy change;
- context exhaustion, ownership conflict, unsafe ambiguity, or no defensible next action;
- a supervising agent determines the human needs to inspect or redirect the work.

Ordinary idle work with a safe next action is not a call. Continue that work.

## Call-quality gate

Every call must name the task/deliverable, explain verified state and consequences, ask one decision, give at least two numbered options, recommend one with a reason, and explain how to answer. The complete speech must fit the live 2,000-character transport; the helper fails closed above 1,900. Never call with only “I need you,” “blocked,” or an unexplained error.

Preview the exact speech with `brief`. Ring with the same fields:

```bash
python3 scripts/contact_human.py ring \
  --task-id TASK_ID --task-title "TASK TITLE" \
  --context "VERIFIED STATE, IMPASSE, AND CONSEQUENCE" \
  --question "ONE DECISION" \
  --option "OPTION ONE AND CONSEQUENCE" \
  --option "OPTION TWO AND CONSEQUENCE" \
  --recommendation "OPTION NUMBER AND REASON"
```

Use `--human-name` and `--caller-name` only when supplied by the local operator/configuration. The skill contains no personal default.

## Listen and complete the loop

The call is two-way, but the reply does not wake the agent. Poll until a new outbound Portal message appears:

```bash
python3 scripts/contact_human.py poll
```

The helper requires the exact transport `call_id` returned by `cell_alert` and polls only outbound Portal transcript rows carrying that same owner-scoped call id. The human answers naturally with the option number and any change; no spoken code is required. Concurrent Portal activity and other calls cannot be mistaken for the answer. Polling never marks messages read and fails closed when correlation state is missing or malformed.

`ring_requested` and `delivery_unknown` mean the call may already have reached the human but no definitive receipt returned. Never retry through this helper or direct MCP in either state. Inspect status and transport evidence, then use an evidenced owner-bound cancellation or repair the route. The same no-rering rule applies to `correlation_failed`.

When an answer appears:

1. Send the owning task the original question and exact answer, plus Portal message id/time.
2. Run `mark-routed --task-id TASK_ID --answer-id PORTAL_MESSAGE_ID --route-receipt RECEIPT`, where the receipt is the owning task's message id or other delivery proof.
3. Verify the task acknowledged and applied the answer through appropriate artifact progress.
4. Run `mark-applied --task-id TASK_ID --evidence EVIDENCE` only after that proof.
5. Run `clear --task-id TASK_ID` after the workflow is closed.

`clear` is allowed only after `mark-applied`. If fresh evidence proves an open intervention stale or unsafe, use `cancel --task-id TASK_ID --evidence EVIDENCE`; cancellation is explicit and never masquerades as completion. Every terminal transition is bound to the exact task owner, and routing is additionally bound to the correlated Portal answer id.

If the answer is ambiguous, ask one concrete clarification; do not guess. If the task ignores or contradicts the answer, escalate that failure explicitly. A human decision that never reaches the work is a broken loop.
