import importlib.util
import io
import json
import multiprocessing
import os
import stat
import subprocess
import tempfile
import time
import unittest
from contextlib import redirect_stdout
from argparse import Namespace
from pathlib import Path
from unittest import mock


SCRIPT = Path(__file__).parents[1] / "scripts" / "contact_human.py"
SPEC = importlib.util.spec_from_file_location("contact_human", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(MODULE)


def concurrent_ring_worker(state_path, counter_path, start_event, result_queue):
    spec = importlib.util.spec_from_file_location("contact_human_worker", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)

    def fake_tool(name, arguments, caller):
        with open(counter_path, "a", encoding="utf-8") as handle:
            handle.write("cell_alert\n")
            handle.flush()
            os.fsync(handle.fileno())
        time.sleep(0.3)
        return {"called": True, "devices_reached": 1, "via_voip": True,
                "reply_capable": True, "has_voice": True,
                "call_id": "11111111-1111-4111-8111-111111111111"}

    module.call_tool = fake_tool
    args = Namespace(state_file=state_path, caller_name="Supervisor", task_id="task-8",
                     task_title="Safe test", context="The task is paused.", question="What next?",
                     option=["resume", "stay paused"], recommendation="option one", human_name="")
    start_event.wait()
    try:
        module.ring(args)
        result_queue.put("success")
    except RuntimeError as error:
        result_queue.put(str(error))


class ContactHumanTests(unittest.TestCase):
    def test_codex_and_claude_default_state_files_are_isolated(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            with mock.patch.dict(os.environ, {"CODEX_HOME": str(base / "codex")}, clear=True):
                codex_state = MODULE.default_state_path()
            with mock.patch.dict(os.environ, {"CLAUDE_CONFIG_DIR": str(base / "claude")}, clear=True):
                claude_state = MODULE.default_state_path()
            with mock.patch.dict(os.environ, {
                "CODEX_HOME": str(base / "codex"),
                "CLAUDE_CONFIG_DIR": str(base / "claude"),
                "CONTACT_HUMAN_STATE_ROOT": str(base / "explicit-contact"),
            }, clear=True):
                explicit_state = MODULE.default_state_path()
            self.assertEqual(codex_state, base / "codex/contact-human-state/state.json")
            self.assertEqual(claude_state, base / "claude/contact-human-state/state.json")
            self.assertEqual(explicit_state, base / "explicit-contact/state.json")
            self.assertEqual(len({codex_state, claude_state, explicit_state}), 3)

    def run_cli(self, *args, expected=0):
        result = subprocess.run(["python3", str(SCRIPT), *args], text=True, capture_output=True)
        self.assertEqual(result.returncode, expected, result.stderr or result.stdout)
        return result

    def test_portal_read_is_transport_scoped_and_non_consuming(self):
        call_id = "11111111-1111-4111-8111-111111111111"
        with mock.patch.object(MODULE, "call_tool", return_value={"messages": []}) as tool:
            MODULE.messages("Supervisor", call_id)
        tool.assert_called_once_with("get_portal_messages", {
            "limit": 100, "direction": "outbound", "agent_name": "all",
            "call_id": call_id, "mark_read": False,
        }, "Supervisor")

    def test_portal_message_schema_failures_are_loud(self):
        call_id = "11111111-1111-4111-8111-111111111111"
        for payload in ({}, {"messages": "none"}, {"messages": ["bad-row"]}):
            with mock.patch.object(MODULE, "call_tool", return_value=payload):
                with self.assertRaisesRegex(RuntimeError, "schema|malformed"):
                    MODULE.messages("Supervisor", call_id)

    def test_reply_requires_exact_call_id_and_post_ring_time(self):
        messages = [
            {"id": "old", "call_id": "11111111-1111-4111-8111-111111111111", "direction": "outbound", "content": "option two", "created_at": "2026-08-08T10:00:00+00:00"},
            {"id": "noise", "call_id": "22222222-2222-4222-8222-222222222222", "direction": "outbound", "content": "option one", "created_at": "2026-08-08T10:02:00+00:00"},
            {"id": "exact", "call_id": "11111111-1111-4111-8111-111111111111", "direction": "outbound", "content": "option one", "created_at": "2026-08-08T10:03:00+00:00"},
        ]
        answer = MODULE.first_new_reply(messages, "11111111-1111-4111-8111-111111111111", "2026-08-08T10:01:00+00:00")
        self.assertEqual(answer["id"], "exact")

    def test_reply_rejects_malformed_rows_and_compares_real_instants(self):
        call_id = "11111111-1111-4111-8111-111111111111"
        rows = [
            {"id": "", "call_id": call_id, "direction": "outbound", "content": "one", "created_at": "2026-08-08T10:03:00Z"},
            {"id": "null", "call_id": call_id, "direction": "outbound", "content": None, "created_at": "2026-08-08T10:03:00Z"},
            {"id": "bad-time", "call_id": call_id, "direction": "outbound", "content": "one", "created_at": "zzz"},
            {"id": "stale-offset", "call_id": call_id, "direction": "outbound", "content": "one", "created_at": "2026-08-08T10:30:00+02:00"},
            {"id": "new", "call_id": call_id, "direction": "outbound", "content": "two", "created_at": "2026-08-08T10:02:00Z"},
        ]
        answer = MODULE.first_new_reply(rows, call_id, "2026-08-08T10:01:00+00:00")
        self.assertEqual(answer["id"], "new")

    def test_concurrent_unrelated_messages_are_rejected(self):
        messages = [
            {"id": "a", "call_id": "22222222-2222-4222-8222-222222222222", "direction": "outbound", "content": "unrelated voice reply", "created_at": "2026-08-08T10:03:00+00:00"},
            {"id": "b", "direction": "outbound", "content": "option one", "created_at": "2026-08-08T10:04:00+00:00"},
        ]
        self.assertIsNone(MODULE.first_new_reply(messages, "11111111-1111-4111-8111-111111111111", "2026-08-08T10:01:00+00:00"))

    def test_missing_or_malformed_correlation_state_fails_before_read(self):
        valid = {"call_id": "11111111-1111-4111-8111-111111111111", "ring_requested_at": "2026-08-08T10:01:00+00:00"}
        for bad in (
            {**valid, "call_id": "newest-call"},
            {**valid, "call_id": None},
            {**valid, "ring_requested_at": ""},
            {**valid, "ring_requested_at": "2026-08-08T10:01:00"},
        ):
            with self.assertRaises(RuntimeError):
                MODULE.validate_correlation_state(bad)

    def test_endpoint_is_pinned_before_credentials_load(self):
        with mock.patch.dict(os.environ, {"SB_MCP_URL": "https://attacker.example/mcp"}, clear=False), \
             mock.patch.object(MODULE, "credentials") as credentials:
            with self.assertRaisesRegex(RuntimeError, "trusted HTTPS"):
                MODULE.call_tool("get_current_time", {}, "Supervisor")
            credentials.assert_not_called()

    def test_mcp_is_error_fails_closed_and_probe_never_reports_ready(self):
        response = mock.MagicMock()
        response.__enter__.return_value.read.return_value = json.dumps({
            "result": {"isError": True, "content": [{"type": "text", "text": "Portal unavailable"}]},
        }).encode()
        opener = mock.MagicMock()
        opener.open.return_value = response
        with mock.patch.object(MODULE, "credentials", return_value=("private", "public")), \
             mock.patch.object(MODULE.urllib.request, "build_opener", return_value=opener):
            with self.assertRaisesRegex(RuntimeError, "delivery outcome is unknown"):
                MODULE.call_tool("get_current_time", {}, "Supervisor")

        output = io.StringIO()
        with mock.patch.object(MODULE, "call_tool", side_effect=RuntimeError("Portal unavailable")), \
             redirect_stdout(output):
            with self.assertRaisesRegex(RuntimeError, "Portal unavailable"):
                MODULE.probe(Namespace(caller_name="Supervisor"))
        self.assertEqual(output.getvalue(), "")

    def test_authenticated_requests_refuse_redirects(self):
        handler = MODULE.NoRedirect()
        request = MODULE.urllib.request.Request(MODULE.DEFAULT_URL)
        self.assertIsNone(handler.redirect_request(
            request, None, 302, "Found", {}, "https://attacker.example/collect"
        ))

    def test_state_permissions_ignore_permissive_umask(self):
        with tempfile.TemporaryDirectory() as temp:
            old = os.umask(0)
            try:
                path = Path(temp) / "state" / "answer.json"
                MODULE.write_state(path, {"status": "answered"})
            finally:
                os.umask(old)
            self.assertEqual(stat.S_IMODE(path.parent.stat().st_mode), 0o700)
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)

    def test_shared_state_parent_is_refused_without_mode_or_sentinel_changes(self):
        with tempfile.TemporaryDirectory() as temp:
            shared = Path(temp) / "shared"
            shared.mkdir(mode=0o755)
            shared.chmod(0o755)
            sentinel = shared / "sentinel.txt"
            sentinel.write_text("keep")
            args = Namespace(state_file=str(shared / "state.json"))
            with self.assertRaisesRegex(RuntimeError, "not private"):
                MODULE.status(args)
            self.assertEqual(stat.S_IMODE(shared.stat().st_mode), 0o755)
            self.assertEqual(sentinel.read_text(), "keep")

    def test_broad_state_path_is_refused(self):
        with self.assertRaisesRegex(RuntimeError, "dedicated private|symbolic links"):
            MODULE.state_file(Namespace(state_file="/tmp/contact-human.json"))

    def test_unrelated_private_json_is_not_claimed_or_overwritten(self):
        with tempfile.TemporaryDirectory() as temp:
            parent = Path(temp) / "private-app"
            parent.mkdir(mode=0o700)
            path = parent / "settings.json"
            original = b'{"status":"closed","unrelated_secret":"preserve-me"}\n'
            path.write_bytes(original)
            args = Namespace(
                state_file=str(path), caller_name="Supervisor", task_id="task-8",
                task_title="Safe test", context="The task is paused.", question="What next?",
                option=["resume", "stay paused"], recommendation="option one", human_name="",
            )
            with mock.patch.object(MODULE, "call_tool") as tool:
                with self.assertRaisesRegex(RuntimeError, "not a contact-human-owned"):
                    MODULE.ring(args)
            tool.assert_not_called()
            self.assertEqual(path.read_bytes(), original)

    def test_nested_symlink_state_path_is_refused(self):
        with tempfile.TemporaryDirectory() as temp:
            real = Path(temp) / "real"
            real.mkdir()
            alias = Path(temp) / "alias"
            alias.symlink_to(real, target_is_directory=True)
            with self.assertRaisesRegex(RuntimeError, "symbolic links"):
                MODULE.state_file(Namespace(state_file=str(alias / "nested" / "state.json")))

    def test_briefing_fits_live_transport(self):
        args = type("Args", (), {
            "option": ["ship", "pause"], "human_name": "", "caller_name": "Supervisor",
            "task_id": "task-8", "task_title": "Test", "context": "x" * 1600, "question": "Choose",
            "recommendation": "option 1",
        })()
        value = MODULE.briefing(args)
        self.assertLessEqual(len(value), 1900)
        self.assertNotIn("code", value.lower())

    def test_cli_rejects_empty_call_quality_fields_and_options(self):
        base = ["brief", "--task-id", "task-8", "--task-title", "Safe test",
                "--context", "Verified state", "--question", "What next?",
                "--option", "resume", "--option", "pause", "--recommendation", "option one"]
        fields = {
            "--task-id": "", "--task-title": " ", "--context": "", "--question": "\t",
            "--recommendation": "", "--option": "",
        }
        for field, empty in fields.items():
            candidate = list(base)
            candidate[candidate.index(field) + 1] = empty
            self.run_cli(*candidate, expected=2)
        self.run_cli("--caller-name", "", *base, expected=2)

    def test_ring_uses_returned_call_id_without_spoken_challenge(self):
        call_id = "11111111-1111-4111-8111-111111111111"
        with tempfile.TemporaryDirectory() as temp:
            args = Namespace(
                state_file=str(Path(temp) / "state.json"), caller_name="Supervisor",
                task_id="task-8", task_title="Safe test", context="The task is paused.",
                question="What next?", option=["resume", "stay paused"],
                recommendation="option one", human_name="",
            )
            with mock.patch.object(MODULE, "call_tool", return_value={
                "called": True, "devices_reached": 1, "via_voip": True,
                "reply_capable": True, "has_voice": True, "call_id": call_id,
            }) as tool:
                MODULE.ring(args)
            sent = tool.call_args.args[1]["message"]
            self.assertNotIn("code", sent.lower())
            self.assertEqual(MODULE.read_state(Path(args.state_file))["call_id"], call_id)

    def test_concurrent_ring_allows_exactly_one_remote_call(self):
        with tempfile.TemporaryDirectory() as temp:
            context = multiprocessing.get_context("fork")
            state_path = str(Path(temp) / "state.json")
            counter_path = str(Path(temp) / "calls.txt")
            start_event = context.Event()
            results = context.Queue()
            processes = [context.Process(target=concurrent_ring_worker,
                                         args=(state_path, counter_path, start_event, results))
                         for _ in range(2)]
            for process in processes:
                process.start()
            start_event.set()
            for process in processes:
                process.join(5)
                self.assertEqual(process.exitcode, 0)
            outcomes = [results.get(timeout=1) for _ in processes]
            self.assertEqual(outcomes.count("success"), 1)
            self.assertEqual(Path(counter_path).read_text().splitlines(), ["cell_alert"])

    def test_transport_failure_locks_unknown_delivery_against_rering(self):
        with tempfile.TemporaryDirectory() as temp:
            args = Namespace(
                state_file=str(Path(temp) / "state.json"), caller_name="Supervisor",
                task_id="task-8", task_title="Safe test", context="The task is paused.",
                question="What next?", option=["resume", "stay paused"],
                recommendation="option one", human_name="",
            )
            with mock.patch.object(MODULE, "call_tool", side_effect=RuntimeError("timeout")) as tool:
                with self.assertRaisesRegex(RuntimeError, "timeout"):
                    MODULE.ring(args)
                with self.assertRaisesRegex(RuntimeError, "already open"):
                    MODULE.ring(args)
            self.assertEqual(tool.call_count, 1)
            self.assertEqual(MODULE.read_state(Path(args.state_file))["status"], "delivery_unknown")

    def test_delivered_ring_without_call_id_fails_closed_against_rering(self):
        with tempfile.TemporaryDirectory() as temp:
            args = Namespace(
                state_file=str(Path(temp) / "state.json"), caller_name="Supervisor",
                task_id="task-8", task_title="Safe test", context="The task is paused.",
                question="What next?", option=["resume", "stay paused"],
                recommendation="option one", human_name="",
            )
            with mock.patch.object(MODULE, "call_tool", return_value={"called": True, "devices_reached": 1, "via_voip": True, "reply_capable": True}):
                with self.assertRaisesRegex(RuntimeError, "reply routing is disabled"):
                    MODULE.ring(args)
            self.assertEqual(MODULE.read_state(Path(args.state_file))["status"], "correlation_failed")
            with self.assertRaisesRegex(RuntimeError, "already open"):
                MODULE.ring(args)

    def test_corrupted_existing_state_fails_closed_without_rering(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "state.json"
            MODULE.ensure_state_root(path)
            original = b"{corrupted"
            path.write_bytes(original)
            args = Namespace(
                state_file=str(path), caller_name="Supervisor", task_id="task-8",
                task_title="Safe test", context="The task is paused.", question="What next?",
                option=["resume", "stay paused"], recommendation="option one", human_name="",
            )
            with mock.patch.object(MODULE, "call_tool") as tool:
                with self.assertRaisesRegex(RuntimeError, "malformed"):
                    MODULE.ring(args)
            tool.assert_not_called()
            self.assertEqual(path.read_bytes(), original)

    def test_existing_empty_or_null_state_fails_closed_without_rering(self):
        for original in (b"{}\n", b'{"status": null}\n'):
            with tempfile.TemporaryDirectory() as temp:
                path = Path(temp) / "state.json"
                MODULE.ensure_state_root(path)
                path.write_bytes(original)
                args = Namespace(
                    state_file=str(path), caller_name="Supervisor", task_id="task-8",
                    task_title="Safe test", context="The task is paused.", question="What next?",
                    option=["resume", "stay paused"], recommendation="option one", human_name="",
                )
                with mock.patch.object(MODULE, "call_tool") as tool:
                    with self.assertRaisesRegex(RuntimeError, "recognized status"):
                        MODULE.ring(args)
                tool.assert_not_called()
                self.assertEqual(path.read_bytes(), original)

    def test_one_way_or_fallback_delivery_never_opens_reply_polling(self):
        call_id = "11111111-1111-4111-8111-111111111111"
        for receipt in (
            {"called": True, "devices_reached": 1, "via_voip": False, "reply_capable": False, "call_id": call_id},
            {"called": True, "devices_reached": 1, "via_voip": True, "reply_capable": False, "call_id": call_id},
            {"called": True, "devices_reached": 1, "via_voip": False, "reply_capable": True, "call_id": call_id},
        ):
            with tempfile.TemporaryDirectory() as temp:
                args = Namespace(
                    state_file=str(Path(temp) / "state.json"), caller_name="Supervisor",
                    task_id="task-8", task_title="Safe test", context="The task is paused.",
                    question="What next?", option=["resume", "stay paused"],
                    recommendation="option one", human_name="",
                )
                with mock.patch.object(MODULE, "call_tool", return_value=receipt):
                    with self.assertRaisesRegex(RuntimeError, "not reply-capable"):
                        MODULE.ring(args)
                self.assertEqual(MODULE.read_state(Path(args.state_file))["status"], "correlation_failed")

    def test_malformed_delivery_receipt_never_opens_reply_polling(self):
        call_id = "11111111-1111-4111-8111-111111111111"
        malformed = (
            {"called": "false", "devices_reached": 1, "via_voip": True,
             "reply_capable": True, "call_id": call_id},
            {"called": True, "devices_reached": "1", "via_voip": True,
             "reply_capable": True, "call_id": call_id},
            {"called": True, "devices_reached": True, "via_voip": True,
             "reply_capable": True, "call_id": call_id},
        )
        for receipt in malformed:
            with tempfile.TemporaryDirectory() as temp:
                args = Namespace(
                    state_file=str(Path(temp) / "state.json"), caller_name="Supervisor",
                    task_id="task-8", task_title="Safe test", context="The task is paused.",
                    question="What next?", option=["resume", "stay paused"],
                    recommendation="option one", human_name="",
                )
                with mock.patch.object(MODULE, "call_tool", return_value=receipt):
                    with self.assertRaisesRegex(RuntimeError, "unknown|ambiguous"):
                        MODULE.ring(args)
                self.assertNotEqual(MODULE.read_state(Path(args.state_file)).get("status"), "awaiting_reply")

    def test_clear_requires_applied_and_cancel_requires_evidence(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "state.json"
            MODULE.write_state(path, {"status": "answered", "task_id": "task-8"})
            args = Namespace(state_file=str(path), task_id="task-8", evidence="intervention became stale")
            with self.assertRaisesRegex(RuntimeError, "Cannot clear"):
                MODULE.clear(args)
            MODULE.cancel(args)
            self.assertEqual(MODULE.read_state(path)["status"], "cancelled")
            MODULE.write_state(path, {"status": "applied", "task_id": "task-8"})
            MODULE.clear(args)
            self.assertEqual(MODULE.read_state(path)["status"], "closed")

    def test_route_apply_and_cancel_reject_empty_receipts(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "state.json"
            MODULE.write_state(path, {"status": "answered", "task_id": "task-8", "answer": {"id": "answer-1"}})
            with self.assertRaisesRegex(ValueError, "route_receipt"):
                MODULE.transition(Namespace(state_file=str(path), task_id="task-8", answer_id="answer-1"), {"answered"}, "routed",
                                  "route_receipt", "  ")
            MODULE.write_state(path, {"status": "routed", "task_id": "task-8"})
            with self.assertRaisesRegex(ValueError, "application_evidence"):
                MODULE.transition(Namespace(state_file=str(path), task_id="task-8"), {"routed"}, "applied",
                                  "application_evidence", "")
            MODULE.write_state(path, {"status": "answered", "task_id": "task-8"})
            with self.assertRaisesRegex(ValueError, "cancel evidence"):
                MODULE.cancel(Namespace(state_file=str(path), task_id="task-8", evidence="\t"))

    def test_wrong_owner_cannot_route_apply_cancel_or_clear(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "state.json"
            cases = [
                ({"status": "answered", "task_id": "task-a", "answer": {"id": "answer-1"}},
                 lambda: MODULE.transition(Namespace(state_file=str(path), task_id="task-b", answer_id="answer-1"),
                                           {"answered"}, "routed", "route_receipt", "receipt")),
                ({"status": "routed", "task_id": "task-a"},
                 lambda: MODULE.transition(Namespace(state_file=str(path), task_id="task-b"),
                                           {"routed"}, "applied", "application_evidence", "proof")),
                ({"status": "answered", "task_id": "task-a"},
                 lambda: MODULE.cancel(Namespace(state_file=str(path), task_id="task-b", evidence="proof"))),
                ({"status": "applied", "task_id": "task-a"},
                 lambda: MODULE.clear(Namespace(state_file=str(path), task_id="task-b"))),
            ]
            for original, action in cases:
                MODULE.write_state(path, original)
                with self.assertRaisesRegex(RuntimeError, "owning task"):
                    action()
                self.assertEqual(MODULE.read_state(path), original)


if __name__ == "__main__":
    unittest.main()
