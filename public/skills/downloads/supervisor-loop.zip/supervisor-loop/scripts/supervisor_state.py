#!/usr/bin/env python3
"""Bounded state helper for the supervisor-loop skill."""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import re
import sys
import tempfile
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

MAX_TICKS = 10
MAX_PENDING_NUDGES = 8
MAX_NUDGE_OUTCOMES = 32
MAX_OBSERVATION_RESETS = 16


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def state_root(explicit: str | None) -> Path:
    if explicit:
        candidate = Path(explicit).expanduser()
        if candidate.is_symlink():
            raise ValueError("supervisor state root may not be a symbolic link")
        root = candidate.resolve()
        forbidden = {Path("/"), Path.home().resolve(), Path("/tmp").resolve()}
        if root in forbidden:
            raise ValueError("supervisor state must use a dedicated private leaf directory")
        marker = root / ".supervisor-state-root"
        legacy_signature = all((root / name).exists() for name in (
            "sessions", "config.json", "fleet.json", "alert-lock.json",
        ))
        lock_bootstrap = False
        if root.exists() and not marker.exists() and not legacy_signature:
            mode = root.stat().st_mode & 0o777
            entries = {item.name for item in root.iterdir()}
            lock_bootstrap = (
                root.is_dir() and root.stat().st_uid == os.getuid() and not mode & 0o077
                and entries <= {".state.lck"}
            )
        if root.exists() and not marker.exists() and not legacy_signature and not lock_bootstrap:
            raise ValueError("existing --root is not a supervisor-owned state directory")
        return root
    base = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
    return (base / "supervisor-loop-state").resolve()


def safe_id(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("._")
    if not cleaned:
        raise ValueError("task id contains no safe filename characters")
    return cleaned


def load_json(path: Path, default):
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def secure_directory(path: Path) -> None:
    if path.exists():
        mode = path.stat().st_mode & 0o777
        if not path.is_dir() or path.stat().st_uid != os.getuid() or mode & 0o077:
            raise ValueError("supervisor state directory is not private and helper-owned")
        return
    try:
        path.mkdir(parents=True, exist_ok=False, mode=0o700)
    except FileExistsError:
        secure_directory(path)
        return
    path.chmod(0o700)


def write_json(path: Path, value) -> None:
    secure_directory(path.parent)
    if path.exists():
        path.chmod(0o600)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        temporary.replace(path)
    except BaseException:
        try:
            os.close(descriptor)
        except OSError:
            pass
        temporary.unlink(missing_ok=True)
        raise
    path.chmod(0o600)


def write_private_text(path: Path, value: str) -> None:
    secure_directory(path.parent)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        temporary.replace(path)
    except BaseException:
        try:
            os.close(descriptor)
        except OSError:
            pass
        temporary.unlink(missing_ok=True)
        raise
    path.chmod(0o600)


@contextmanager
def interprocess_lock(path: Path):
    secure_directory(path.parent)
    descriptor = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
    try:
        os.fchmod(descriptor, 0o600)
        fcntl.flock(descriptor, fcntl.LOCK_EX)
        yield
    finally:
        fcntl.flock(descriptor, fcntl.LOCK_UN)
        os.close(descriptor)


def ensure(root: Path) -> None:
    secure_directory(root)
    marker = root / ".supervisor-state-root"
    if not marker.exists():
        try:
            descriptor = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            descriptor = None
        if descriptor is not None:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                handle.write("supervisor-loop-state-v1\n")
                handle.flush()
                os.fsync(handle.fileno())
    if marker.read_text() != "supervisor-loop-state-v1\n":
        entries = {item.name for item in root.iterdir()}
        if entries <= {".state.lck", ".supervisor-state-root"}:
            descriptor = os.open(marker, os.O_WRONLY | os.O_TRUNC)
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                handle.write("supervisor-loop-state-v1\n")
                handle.flush()
                os.fsync(handle.fileno())
        else:
            raise ValueError("supervisor state ownership marker is invalid")
    secure_directory(root / "sessions")
    config = root / "config.json"
    fleet = root / "fleet.json"
    lock = root / "alert-lock.json"
    watchlist = root / "watchlist.md"
    if not config.exists():
        write_json(config, {"automation_id": None, "cadence_minutes": 10})
    else:
        config_data = load_json(config, {})
        normalized_config = {
            "automation_id": config_data.get("automation_id"),
            "cadence_minutes": config_data.get("cadence_minutes", 10),
            **config_data,
        }
        if normalized_config != config_data:
            write_json(config, normalized_config)
    if not fleet.exists():
        write_json(fleet, {"created_at": now(), "quiet_streak": 0, "ticks": []})
    else:
        fleet_data = load_json(fleet, {})
        normalized_fleet = {
            "created_at": fleet_data.get("created_at", now()),
            "quiet_streak": fleet_data.get("quiet_streak", 0),
            "ticks": fleet_data.get("ticks", []),
            **fleet_data,
        }
        if normalized_fleet != fleet_data:
            write_json(fleet, normalized_fleet)
    if not lock.exists():
        write_json(lock, {"open_question": None, "pending_questions": []})
    else:
        lock_data = load_json(lock, {})
        normalized_lock = {
            "open_question": lock_data.get("open_question"),
            "pending_questions": lock_data.get("pending_questions", []),
            **lock_data,
        }
        if normalized_lock != lock_data:
            write_json(lock, normalized_lock)
    if not watchlist.exists():
        write_private_text(watchlist, "# Supervisor watchlist\n\n")
    watchlist.chmod(0o600)
    for path in (config, fleet, lock):
        path.chmod(0o600)
    for path in (root / "sessions").glob("*.json"):
        path.chmod(0o600)


def session_path(root: Path, task_id: str) -> Path:
    readable = safe_id(task_id)[:80]
    identity = hashlib.sha256(task_id.encode("utf-8")).hexdigest()[:16]
    return root / "sessions" / f"{readable}-{identity}.json"


def legacy_session_path(root: Path, task_id: str) -> Path:
    return root / "sessions" / f"{safe_id(task_id)}.json"


def load_session(root: Path, task_id: str) -> dict:
    path = session_path(root, task_id)
    legacy = legacy_session_path(root, task_id)
    if not path.exists() and legacy.exists():
        legacy_data = load_json(legacy, {})
        if legacy_data.get("task_id") != task_id:
            print("ERROR: legacy session filename collision; refusing cross-task state", file=sys.stderr)
            raise SystemExit(6)
        legacy.replace(path)
    data = load_json(path, None)
    if data is None:
        data = {
            "task_id": task_id,
            "title": "",
            "deliverable": "",
            "repo": None,
            "queue_file": None,
            "watched": True,
            "observation_only": False,
            "corrections": 0,
            "nudges": {"accurate": 0, "withdrawn": 0, "corrected": 0, "pending": 0},
            "nudge_outcomes": [],
            "observation_resets": [],
            "escalation": 0,
            "attempt_epoch": 0,
            "churn_guard": {},
            "ticks": [],
        }
    elif data.get("task_id") != task_id:
        print("ERROR: session identity mismatch; refusing cross-task state", file=sys.stderr)
        raise SystemExit(6)
    data.setdefault("attempt_epoch", 0)
    data.setdefault("churn_guard", {})
    data.setdefault("nudges", {})
    for key in ("accurate", "withdrawn", "corrected", "pending"):
        data["nudges"].setdefault(key, 0)
    data.setdefault("nudge_outcomes", [])
    data.setdefault("observation_resets", [])
    return data


def save_session(root: Path, data: dict) -> None:
    data["updated_at"] = now()
    kept = []
    routine_count = 0
    for tick in data.get("ticks", []):
        unresolved_nudge = tick.get("action") == "nudge" and tick.get("nudge_outcome") is None
        if unresolved_nudge or routine_count < MAX_TICKS:
            kept.append(tick)
            if not unresolved_nudge:
                routine_count += 1
    data["ticks"] = kept
    write_json(session_path(root, data["task_id"]), data)


def all_sessions(root: Path) -> list[dict]:
    result = []
    for path in sorted((root / "sessions").glob("*.json")):
        result.append(load_json(path, {}))
    return result


def regenerate_watchlist(root: Path) -> None:
    watched = [item for item in all_sessions(root) if item.get("watched")]
    lines = ["# Supervisor watchlist", "", "Deliverables only. Tick history lives in `sessions/`.", ""]
    for item in sorted(watched, key=lambda x: (x.get("title") or x.get("task_id", "")).lower()):
        state = "observation-only" if item.get("observation_only") else "watched"
        lines.append(
            f"- {inert_markdown(item['task_id'])} | {inert_markdown(item.get('title') or '(untitled)')} | "
            f"{inert_markdown(item.get('deliverable') or '(deliverable needed)')} | {state}"
        )
    write_private_text(root / "watchlist.md", "\n".join(lines) + "\n")


def inert_markdown(value: str) -> str:
    single_line = re.sub(r"[\x00-\x1f\x7f]+", " ", str(value))
    single_line = re.sub(r"\s+", " ", single_line).strip()
    return re.sub(r"([\\`|<>\[\]{}()!*_#])", r"\\\1", single_line)


def bool_text(value: str) -> bool | None:
    lowered = value.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered == "unknown":
        return None
    raise argparse.ArgumentTypeError("expected true, false, or unknown")


def nonblank_text(value: str) -> str:
    normalized = value.strip()
    if not normalized:
        raise argparse.ArgumentTypeError("value must contain non-whitespace text")
    return normalized


def cmd_init(args, root: Path) -> None:
    ensure(root)
    print(root)


def cmd_set_deliverable(args, root: Path) -> None:
    ensure(root)
    data = load_session(root, args.task_id)
    data.update({
        "title": args.title,
        "deliverable": args.deliverable,
        "repo": args.repo if args.repo is not None else data.get("repo"),
        "queue_file": args.queue_file if args.queue_file is not None else data.get("queue_file"),
        "deliverable_source": args.source or data.get("deliverable_source") or "operator",
        "discovered_at": args.discovered_at or data.get("discovered_at") or now(),
        "watched": True,
    })
    save_session(root, data)
    regenerate_watchlist(root)
    print(f"watching {args.task_id}: {args.deliverable}")


def cmd_record_tick(args, root: Path) -> None:
    ensure(root)
    data = load_session(root, args.task_id)
    existing_tick = next((item for item in data.get("ticks", []) if item.get("tick_id") == args.tick_id), None)
    if existing_tick:
        replay_fields = {
            "running": args.running,
            "status": args.status,
            "last_activity": args.last_activity,
            "waiting_on": args.waiting_on,
            "unblocker": args.unblocker,
            "rule": args.rule,
            "action": args.action,
            "premise_key": args.premise_key,
            "evidence": args.evidence,
            "direction": args.direction,
            "attempt_class": args.attempt_class,
            "strategy": args.strategy,
            "result": args.result,
            "operation_key": args.operation_key,
            "artifact_key": args.artifact_key,
            "operator_intervention": args.operator_intervention,
            "intervention_reason": args.intervention_reason,
            "note": args.note,
        }
        if args.observed_at is not None:
            replay_fields["observed_at"] = args.observed_at
        conflicts = []
        for key, value in replay_fields.items():
            existing_value = existing_tick.get("requested_action", existing_tick.get("action")) if key == "action" else existing_tick.get(key)
            if existing_value != value:
                conflicts.append(key)
        if conflicts:
            print(f"ERROR: tick id is immutable; conflicting replay fields: {', '.join(conflicts)}", file=sys.stderr)
            raise SystemExit(3)
        print(json.dumps({
            "task_id": args.task_id,
            "tick_id": args.tick_id,
            "attempt_verdict": existing_tick.get("attempt_verdict"),
            "artifact_progress": bool(existing_tick.get("artifact_progress")),
            "duplicate_operation_count": existing_tick.get("duplicate_operation_count", 1),
            "no_artifact_progress_ticks": existing_tick.get("no_artifact_progress_ticks", 1),
            "strategy_change_required": bool(data.get("strategy_change_required")),
            "intervention_required": bool(data.get("intervention_required")),
            "idempotent_replay": True,
        }, sort_keys=True))
        return
    all_prior_ticks = [item for item in data.get("ticks", []) if item.get("tick_id") != args.tick_id]
    previous_artifact = data.get("last_artifact_key") or next(
        (item.get("artifact_key") for item in all_prior_ticks if item.get("artifact_key")), None
    )
    failing_now = args.result in {"failed", "no-new-evidence"}
    artifact_changed = bool(args.artifact_key and previous_artifact and args.artifact_key != previous_artifact)
    artifact_progress = artifact_changed and args.direction == "aligned" and not failing_now
    if artifact_progress and existing_tick is None:
        data["escalation"] = 0
        data["last_premise_key"] = None
    if failing_now and (not args.attempt_class or not args.strategy):
        print("ERROR: failed attempts require nonblank attempt class and strategy", file=sys.stderr)
        raise SystemExit(2)
    if bool(args.attempt_class) != bool(args.strategy):
        print("ERROR: attempt class and strategy must be provided together", file=sys.stderr)
        raise SystemExit(2)
    if args.action == "nudge":
        if data.get("observation_only") and not (existing_tick and existing_tick.get("action") == "nudge"):
            print("ERROR: task is observation-only; nudge refused", file=sys.stderr)
            raise SystemExit(5)
        if not any(str(item).strip() for item in args.evidence):
            print("ERROR: nudge requires nonblank artifact evidence", file=sys.stderr)
            raise SystemExit(2)
        if not args.premise_key or not args.premise_key.strip():
            print("ERROR: nudge requires a nonblank premise key", file=sys.stderr)
            raise SystemExit(2)
        if data["nudges"].get("pending", 0) >= MAX_PENDING_NUDGES:
            print("ERROR: pending nudge ledger is full; resolve an existing nudge before issuing another", file=sys.stderr)
            raise SystemExit(5)
    premise_nudge_refused = (
        args.action == "nudge"
        and not (existing_tick and existing_tick.get("action") == "nudge")
        and args.premise_key == data.get("last_premise_key")
        and data.get("escalation", 0) >= 2
    )
    effective_action = "report" if premise_nudge_refused else args.action
    if premise_nudge_refused:
        data["intervention_required"] = True
        data["intervention_reason"] = "third nudge on unchanged premise refused"
        data["intervention_detected_at"] = data.get("intervention_detected_at") or now()
    previous_running = data.get("last_running")
    if args.running is False and previous_running is not False:
        data["idle_since"] = args.observed_at or now()
    elif args.running is True:
        data["idle_since"] = None
    data.update({
        "title": args.title or data.get("title", ""),
        "last_running": args.running,
        "last_status": args.status,
        "last_activity": args.last_activity,
        "waiting_on": args.waiting_on,
        "unblocker": args.unblocker,
    })
    current_epoch = data.get("attempt_epoch", 0)
    if existing_tick:
        current_epoch = existing_tick.get("attempt_epoch", current_epoch)
    elif artifact_progress or args.result == "success":
        current_epoch += 1
        data["attempt_epoch"] = current_epoch
    guard = data.setdefault("churn_guard", {})
    if guard.get("epoch") != current_epoch:
        guard = {"epoch": current_epoch, "strategy_failures": {}, "failed_strategies": {},
                 "last_operation_key": None, "last_operation_artifact": None,
                 "duplicate_operation_count": 0, "last_artifact_key": None,
                 "no_artifact_progress_ticks": 0}
        data["churn_guard"] = guard
    strategy_key = json.dumps([args.attempt_class, args.strategy], separators=(",", ":"))
    same_strategy_failure_count = int(guard.get("strategy_failures", {}).get(strategy_key, 0))
    failed_strategies = set(guard.get("failed_strategies", {}).get(args.attempt_class or "", []))
    refused_attempt = failing_now and bool(args.attempt_class) and bool(args.strategy) and same_strategy_failure_count >= 2
    if refused_attempt:
        data["intervention_required"] = True
        data["intervention_reason"] = "third identical strategy refused"
        data["intervention_detected_at"] = data.get("intervention_detected_at") or now()
        data["rejected_attempt"] = {"tick_id": args.tick_id, "attempt_class": args.attempt_class,
                                    "strategy": args.strategy, "result": args.result}
    duplicate_operation_count = 1
    if args.operation_key:
        if (guard.get("last_operation_key") == args.operation_key
                and guard.get("last_operation_artifact") == args.artifact_key):
            duplicate_operation_count = int(guard.get("duplicate_operation_count", 0)) + 1
    no_artifact_progress_ticks = 1
    if args.artifact_key:
        if guard.get("last_artifact_key") == args.artifact_key:
            no_artifact_progress_ticks = int(guard.get("no_artifact_progress_ticks", 0)) + 1

    attempt_verdict = "intervene" if refused_attempt else "observe"
    if artifact_progress and not refused_attempt:
        attempt_verdict = "progress"
        data["strategy_change_required"] = False
    elif args.operation_key and duplicate_operation_count >= 3:
        attempt_verdict = "intervene"
        data["intervention_required"] = True
        data["intervention_reason"] = "third duplicate operation without artifact progress"
        data["intervention_detected_at"] = data.get("intervention_detected_at") or now()
    elif args.operation_key and duplicate_operation_count >= 2:
        attempt_verdict = "change-strategy"
        data["strategy_change_required"] = True
    elif args.running is True and args.artifact_key and no_artifact_progress_ticks >= 2:
        attempt_verdict = "inspect-active"

    tick = {
        "tick_id": args.tick_id,
        "observed_at": args.observed_at or now(),
        "running": args.running,
        "status": args.status,
        "last_activity": args.last_activity,
        "waiting_on": args.waiting_on,
        "unblocker": args.unblocker,
        "rule": args.rule,
        "action": effective_action,
        "requested_action": args.action,
        "premise_key": args.premise_key,
        "evidence": args.evidence,
        "direction": args.direction,
        "attempt_class": args.attempt_class,
        "strategy": args.strategy,
        "result": args.result,
        "operation_key": args.operation_key,
        "artifact_key": args.artifact_key,
        "operator_intervention": args.operator_intervention,
        "intervention_reason": args.intervention_reason,
        "artifact_progress": artifact_progress,
        "artifact_changed": artifact_changed,
        "attempt_epoch": current_epoch,
        "duplicate_operation_count": duplicate_operation_count,
        "no_artifact_progress_ticks": no_artifact_progress_ticks,
        "attempt_verdict": attempt_verdict,
        "note": args.note,
    }
    if failing_now and args.attempt_class and args.strategy:
        guard.setdefault("strategy_failures", {})[strategy_key] = min(3, same_strategy_failure_count + 1)
        class_strategies = guard.setdefault("failed_strategies", {}).setdefault(args.attempt_class, [])
        if args.strategy not in class_strategies:
            class_strategies.append(args.strategy)
        if same_strategy_failure_count + 1 >= 2:
            data["strategy_change_required"] = True
        if args.strategy not in failed_strategies and len(failed_strategies) >= 1:
            data["intervention_required"] = True
            data["intervention_reason"] = "second distinct strategy failed"
            data["intervention_detected_at"] = data.get("intervention_detected_at") or now()
            attempt_verdict = "intervene"
    elif args.result == "success":
        data["strategy_change_required"] = False
    if args.operator_intervention:
        data["intervention_required"] = True
        data["intervention_reason"] = args.intervention_reason or "operator intervention requested"
        data["intervention_detected_at"] = data.get("intervention_detected_at") or now()
        attempt_verdict = "intervene"
    if premise_nudge_refused:
        attempt_verdict = "intervene"
    tick["attempt_verdict"] = attempt_verdict
    if args.operation_key:
        guard["last_operation_key"] = args.operation_key
        guard["last_operation_artifact"] = args.artifact_key
        guard["duplicate_operation_count"] = duplicate_operation_count
    else:
        guard["last_operation_key"] = None
        guard["last_operation_artifact"] = None
        guard["duplicate_operation_count"] = 0
    if args.artifact_key:
        guard["last_artifact_key"] = args.artifact_key
        guard["no_artifact_progress_ticks"] = no_artifact_progress_ticks
        data["last_artifact_key"] = args.artifact_key
    data["ticks"] = [tick] + [item for item in data.get("ticks", []) if item.get("tick_id") != args.tick_id]
    if effective_action == "nudge" and (not existing_tick or existing_tick.get("action") != "nudge"):
        data["nudges"]["pending"] = data["nudges"].get("pending", 0) + 1
        if args.premise_key and args.premise_key == data.get("last_premise_key"):
            data["escalation"] = data.get("escalation", 0) + 1
        else:
            data["escalation"] = 1
        data["last_premise_key"] = args.premise_key
    elif existing_tick and existing_tick.get("action") == "nudge" and effective_action != "nudge":
        data["nudges"]["pending"] = max(0, data["nudges"].get("pending", 0) - 1)
    save_session(root, data)
    if refused_attempt:
        print("ERROR: third identical failed strategy refused; operator intervention required", file=sys.stderr)
        raise SystemExit(5)
    if premise_nudge_refused:
        print("ERROR: third nudge on unchanged premise refused; operator intervention required", file=sys.stderr)
        raise SystemExit(5)
    print(json.dumps({
        "task_id": args.task_id,
        "tick_id": args.tick_id,
        "attempt_verdict": attempt_verdict,
        "artifact_progress": artifact_progress,
        "duplicate_operation_count": duplicate_operation_count,
        "no_artifact_progress_ticks": no_artifact_progress_ticks,
        "strategy_change_required": bool(data.get("strategy_change_required")),
        "intervention_required": bool(data.get("intervention_required")),
    }, sort_keys=True))


def cmd_mark_nudge(args, root: Path) -> None:
    ensure(root)
    data = load_session(root, args.task_id)
    nudges = data.setdefault("nudges", {"accurate": 0, "withdrawn": 0, "corrected": 0, "pending": 0})
    tick = next((item for item in data.get("ticks", []) if item.get("tick_id") == args.tick_id), None)
    if not tick or tick.get("action") != "nudge" or tick.get("nudge_outcome") is not None or nudges.get("pending", 0) <= 0:
        print("ERROR: no matching unresolved nudge for this tick", file=sys.stderr)
        raise SystemExit(3)
    tick["nudge_outcome"] = args.outcome
    tick["nudge_closed_at"] = now()
    tick["nudge_outcome_evidence"] = args.evidence
    data.setdefault("nudge_outcomes", []).insert(0, {
        "tick_id": args.tick_id,
        "outcome": args.outcome,
        "closed_at": tick["nudge_closed_at"],
        "evidence": args.evidence,
    })
    data["nudge_outcomes"] = data["nudge_outcomes"][:MAX_NUDGE_OUTCOMES]
    nudges["pending"] = max(0, nudges.get("pending", 0) - 1)
    if args.outcome == "accurate":
        nudges["accurate"] = nudges.get("accurate", 0) + 1
    elif args.outcome == "withdrawn":
        nudges["withdrawn"] = nudges.get("withdrawn", 0) + 1
        data["corrections"] = data.get("corrections", 0) + 1
        data["escalation"] = 0
        if data["corrections"] >= 2:
            data["observation_only"] = True
    else:
        nudges["corrected"] = nudges.get("corrected", 0) + 1
        data["corrections"] = data.get("corrections", 0) + 1
        data["escalation"] = 0
        if data["corrections"] >= 2:
            data["observation_only"] = True
    save_session(root, data)
    regenerate_watchlist(root)
    print(json.dumps({"task_id": args.task_id, "observation_only": data["observation_only"], "nudges": nudges}))


def cmd_reset_observation(args, root: Path) -> None:
    ensure(root)
    data = load_session(root, args.task_id)
    if not data.get("observation_only"):
        print("ERROR: task is not in observation-only mode", file=sys.stderr)
        raise SystemExit(3)
    data.setdefault("observation_resets", []).insert(0, {
        "reset_at": now(),
        "operator": args.operator,
        "evidence": args.evidence,
        "corrections_at_reset": data.get("corrections", 0),
    })
    data["observation_resets"] = data["observation_resets"][:MAX_OBSERVATION_RESETS]
    data["observation_only"] = False
    data["corrections"] = 0
    data["escalation"] = 0
    data["last_premise_key"] = None
    save_session(root, data)
    regenerate_watchlist(root)
    print(json.dumps({"task_id": args.task_id, "observation_only": False,
                      "reset": data["observation_resets"][0]}, sort_keys=True))


def cmd_resolve_intervention(args, root: Path) -> None:
    ensure(root)
    data = load_session(root, args.task_id)
    if not data.get("intervention_required"):
        print("ERROR: task has no required intervention to resolve", file=sys.stderr)
        raise SystemExit(3)
    data["last_resolved_intervention"] = {
        "reason": data.get("intervention_reason"),
        "detected_at": data.get("intervention_detected_at"),
        "resolved_at": now(),
        "evidence": args.evidence,
    }
    data["intervention_required"] = False
    data["intervention_reason"] = None
    data["intervention_detected_at"] = None
    data["rejected_attempt"] = None
    data["strategy_change_required"] = False
    data["attempt_epoch"] = data.get("attempt_epoch", 0) + 1
    data["churn_guard"] = {}
    data["escalation"] = 0
    data["last_premise_key"] = None
    save_session(root, data)
    print(json.dumps({"task_id": args.task_id, "intervention_required": False}))


def cmd_drop(args, root: Path) -> None:
    ensure(root)
    data = load_session(root, args.task_id)
    data["watched"] = False
    data["dropped_at"] = now()
    data["drop_reason"] = args.reason
    save_session(root, data)
    regenerate_watchlist(root)
    print("Dropped from supervision only; the task itself was not stopped and may keep spending.")


def cmd_configure(args, root: Path) -> None:
    ensure(root)
    config = load_json(root / "config.json", {})
    if args.automation_id is not None:
        config["automation_id"] = args.automation_id
    if args.cadence_minutes is not None:
        config["cadence_minutes"] = args.cadence_minutes
    write_json(root / "config.json", config)
    print(json.dumps(config))


def cmd_alert(args, root: Path) -> None:
    ensure(root)
    path = root / "alert-lock.json"
    if args.alert_action == "show":
        lock = load_json(path, {"open_question": None, "pending_questions": []})
        print(json.dumps(lock, indent=2, sort_keys=True))
        return
    with interprocess_lock(root / ".alert-lock.lck"):
        lock = load_json(path, {"open_question": None, "pending_questions": []})
        lock.setdefault("pending_questions", [])
        if args.alert_action == "acquire":
            if args.operator_contacted and not args.contact_receipt:
                print("ERROR: contacted alert requires a nonblank contact receipt", file=sys.stderr)
                raise SystemExit(2)
            if args.contact_receipt and not args.operator_contacted:
                print("ERROR: contact receipt requires --operator-contacted", file=sys.stderr)
                raise SystemExit(2)
            if lock.get("open_question"):
                same_owner = (
                    lock["open_question"].get("task_id") == args.task_id
                    and lock["open_question"].get("question") == args.question
                )
                if same_owner:
                    if args.operator_contacted:
                        prior_receipt = lock["open_question"].get("contact_receipt")
                        if prior_receipt and prior_receipt != args.contact_receipt:
                            print("ERROR: contacted alert receipt is immutable", file=sys.stderr)
                            raise SystemExit(3)
                        lock["open_question"]["operator_contacted"] = True
                        lock["open_question"]["contact_receipt"] = args.contact_receipt
                        lock["open_question"]["contacted_at"] = lock["open_question"].get("contacted_at") or now()
                    write_json(path, lock)
                    print(json.dumps({"status": "open", "lock": lock}, indent=2, sort_keys=True))
                    return
                if args.operator_contacted:
                    print("ERROR: cannot mark a queued non-owning alert as contacted", file=sys.stderr)
                    raise SystemExit(3)
                pending = lock["pending_questions"]
                duplicate = any(item.get("task_id") == args.task_id and item.get("question") == args.question for item in pending)
                if not duplicate and not (
                    lock["open_question"].get("task_id") == args.task_id
                    and lock["open_question"].get("question") == args.question
                ):
                    if len(pending) >= 8:
                        print("ERROR: pending operator-question queue is full; question was not queued", file=sys.stderr)
                        raise SystemExit(4)
                    pending.append({
                        "task_id": args.task_id,
                        "question": args.question,
                        "queued_at": now(),
                        "alert_route": args.alert_route,
                        "operator_contacted": False,
                        "intervention_detected_at": args.intervention_detected_at or now(),
                    })
                    lock["pending_questions"] = pending
                write_json(path, lock)
                print(json.dumps({"status": "queued", "lock": lock}, indent=2, sort_keys=True))
                return
            matching = next((
                item for item in lock["pending_questions"]
                if item.get("task_id") == args.task_id and item.get("question") == args.question
            ), None)
            lock["pending_questions"] = [
                item for item in lock["pending_questions"]
                if not (item.get("task_id") == args.task_id and item.get("question") == args.question)
            ]
            lock["open_question"] = {
                "task_id": args.task_id,
                "question": args.question,
                "opened_at": now(),
                "queued_at": matching.get("queued_at") if matching else None,
                "alert_route": args.alert_route,
                "operator_contacted": args.operator_contacted,
                "contact_receipt": args.contact_receipt,
                "contacted_at": now() if args.operator_contacted else None,
                "intervention_detected_at": args.intervention_detected_at
                    or (matching.get("intervention_detected_at") if matching else None) or now(),
            }
        elif args.alert_action == "release":
            if not lock.get("open_question"):
                print("ERROR: no operator question holds the alert lock", file=sys.stderr)
                raise SystemExit(3)
            open_question = lock["open_question"]
            if open_question.get("task_id") != args.task_id or open_question.get("question") != args.question:
                print("ERROR: release does not match the owning intervention", file=sys.stderr)
                raise SystemExit(3)
            lock["last_closed_question"] = {**open_question, "closed_at": now(), "resolution": args.resolution,
                                            "route_receipt": args.route_receipt}
            lock["open_question"] = None
        elif args.alert_action == "cancel-open":
            open_question = lock.get("open_question")
            if not open_question or open_question.get("task_id") != args.task_id or open_question.get("question") != args.question:
                print("ERROR: cancel does not match the owning intervention", file=sys.stderr)
                raise SystemExit(3)
            lock["last_cancelled_question"] = {**open_question, "cancelled_at": now(), "cancel_evidence": args.evidence}
            lock["open_question"] = None
        else:
            before = len(lock["pending_questions"])
            lock["pending_questions"] = [
                item for item in lock["pending_questions"]
                if not (
                    item.get("task_id") == args.task_id
                    and (args.question is None or item.get("question") == args.question)
                )
            ]
            if len(lock["pending_questions"]) == before:
                print("ERROR: no matching pending operator question", file=sys.stderr)
                raise SystemExit(3)
        write_json(path, lock)
    print(json.dumps(lock, indent=2, sort_keys=True))


def cmd_close_tick(args, root: Path) -> None:
    ensure(root)
    watched = {item.get("task_id") for item in all_sessions(root) if item.get("watched")}
    examined = set(args.examined)
    if examined != watched:
        omitted = sorted(str(item) for item in watched - examined)
        unexpected = sorted(str(item) for item in examined - watched)
        details = []
        if omitted:
            details.append(f"omitted watched tasks: {', '.join(omitted)}")
        if unexpected:
            details.append(f"unexpected tasks: {', '.join(unexpected)}")
        print(f"ERROR: sweep set is incomplete ({'; '.join(details)})", file=sys.stderr)
        raise SystemExit(2)
    missing = []
    current_ticks = []
    current_sessions = []
    for task_id in args.examined:
        data = load_session(root, task_id)
        current_sessions.append(data)
        current = next((item for item in data.get("ticks", []) if item.get("tick_id") == args.tick_id), None)
        if current is None:
            missing.append(task_id)
        else:
            current_ticks.append(current)
    if missing:
        print(f"ERROR: ledgers missing tick {args.tick_id}: {', '.join(missing)}", file=sys.stderr)
        raise SystemExit(2)
    fleet_path = root / "fleet.json"
    fleet = load_json(fleet_path, {"quiet_streak": 0, "ticks": []})
    existing_close = next((item for item in fleet.get("ticks", []) if item.get("tick_id") == args.tick_id), None)
    if existing_close:
        expected = {
            "examined": args.examined,
            "quiet": args.quiet,
            "proxy_cost": {
                "list_calls": args.list_calls,
                "tail_turns": args.tail_turns,
                "artifact_checks": args.artifact_checks,
                "messages_sent": args.messages_sent,
                "shell_checks": args.shell_checks,
            },
            "exact_cost_dollars": args.exact_cost_dollars,
            "exact_input_tokens": args.exact_input_tokens,
            "exact_output_tokens": args.exact_output_tokens,
            "note": args.note,
        }
        conflicts = [key for key, value in expected.items() if existing_close.get(key) != value]
        if conflicts:
            print(f"ERROR: fleet tick id is immutable; conflicting replay fields: {', '.join(conflicts)}", file=sys.stderr)
            raise SystemExit(3)
        print(json.dumps({
            "tick_id": args.tick_id,
            "ledgers_current": True,
            "quiet_streak": fleet.get("quiet_streak", 0),
            "recommended_cadence_minutes": fleet.get("recommended_cadence_minutes", 10),
            "idempotent_replay": True,
        }))
        return

    alert_state = load_json(root / "alert-lock.json", {"open_question": None, "pending_questions": []})
    if args.quiet:
        tick_is_active = any(
            item.get("action") in {"nudge", "report"}
            or item.get("attempt_verdict") != "observe"
            for item in current_ticks
        )
        carried_intervention = any(
            item.get("intervention_required") or item.get("strategy_change_required")
            for item in current_sessions
        )
        alert_active = bool(alert_state.get("open_question") or alert_state.get("pending_questions"))
        if tick_is_active or carried_intervention or alert_active:
            print("ERROR: tick has active progress, inspection, strategy change, intervention, or alert and cannot be quiet", file=sys.stderr)
            raise SystemExit(2)

    tick = {
        "tick_id": args.tick_id,
        "closed_at": now(),
        "examined": args.examined,
        "quiet": args.quiet,
        "proxy_cost": {
            "list_calls": args.list_calls,
            "tail_turns": args.tail_turns,
            "artifact_checks": args.artifact_checks,
            "messages_sent": args.messages_sent,
            "shell_checks": args.shell_checks,
        },
        "exact_cost_dollars": args.exact_cost_dollars,
        "exact_input_tokens": args.exact_input_tokens,
        "exact_output_tokens": args.exact_output_tokens,
        "recommended_cadence_minutes": 10,
        "note": args.note,
    }
    fleet["ticks"] = [tick] + [item for item in fleet.get("ticks", []) if item.get("tick_id") != args.tick_id]
    fleet["ticks"] = fleet["ticks"][:MAX_TICKS]
    quiet_streak = 0
    for item in fleet["ticks"]:
        if not item.get("quiet"):
            break
        quiet_streak += 1
    fleet["quiet_streak"] = quiet_streak
    recommended = 20 if quiet_streak >= 2 else 10
    tick["recommended_cadence_minutes"] = recommended
    fleet["last_tick_id"] = args.tick_id
    fleet["recommended_cadence_minutes"] = recommended
    write_json(fleet_path, fleet)
    print(json.dumps({"tick_id": args.tick_id, "ledgers_current": True, "quiet_streak": fleet["quiet_streak"], "recommended_cadence_minutes": recommended}))


def cmd_show(args, root: Path) -> None:
    ensure(root)
    payload = {
        "root": str(root),
        "config": load_json(root / "config.json", {}),
        "fleet": load_json(root / "fleet.json", {}),
        "alert_lock": load_json(root / "alert-lock.json", {}),
        "sessions": all_sessions(root),
    }
    print(json.dumps(payload, indent=2, sort_keys=True))


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser()
    result.add_argument("--root", help="override the supervisor state root")
    sub = result.add_subparsers(dest="command", required=True)

    sub.add_parser("init")

    set_delivery = sub.add_parser("set-deliverable")
    set_delivery.add_argument("task_id", type=nonblank_text)
    set_delivery.add_argument("--title", required=True, type=nonblank_text)
    set_delivery.add_argument("--deliverable", required=True, type=nonblank_text)
    set_delivery.add_argument("--source", choices=["operator", "inferred"])
    set_delivery.add_argument("--discovered-at")
    set_delivery.add_argument("--repo")
    set_delivery.add_argument("--queue-file")

    record = sub.add_parser("record-tick")
    record.add_argument("task_id", type=nonblank_text)
    record.add_argument("--tick-id", required=True, type=nonblank_text)
    record.add_argument("--observed-at")
    record.add_argument("--title")
    record.add_argument("--running", type=bool_text, required=True)
    record.add_argument("--status", required=True, type=nonblank_text)
    record.add_argument("--last-activity")
    record.add_argument("--waiting-on", required=True, type=nonblank_text)
    record.add_argument("--unblocker", required=True, type=nonblank_text)
    record.add_argument("--rule", choices=["R1", "R2", "R3", "R4", "R5", "R6", "none"], required=True)
    record.add_argument("--action", choices=["nudge", "report", "no-nudge", "drop"], required=True)
    record.add_argument("--premise-key", type=nonblank_text, help="stable key for escalation of the same verified premise")
    record.add_argument("--evidence", action="append", default=[], type=nonblank_text)
    record.add_argument("--direction", choices=["aligned", "drifting", "unknown"], required=True)
    record.add_argument("--attempt-class", type=nonblank_text)
    record.add_argument("--strategy", type=nonblank_text)
    record.add_argument("--operation-key", type=nonblank_text, help="stable normalized command/check/fix fingerprint")
    record.add_argument("--artifact-key", type=nonblank_text, help="stable commit/PR/build/deliverable artifact fingerprint")
    record.add_argument("--result", choices=["success", "failed", "no-new-evidence", "not-attempted"], default="not-attempted")
    record.add_argument("--operator-intervention", action="store_true")
    record.add_argument("--intervention-reason")
    record.add_argument("--note")

    mark = sub.add_parser("mark-nudge")
    mark.add_argument("task_id")
    mark.add_argument("--tick-id", required=True, type=nonblank_text)
    mark.add_argument("--outcome", choices=["accurate", "withdrawn", "corrected"], required=True)
    mark.add_argument("--evidence", required=True, type=nonblank_text)

    resolve = sub.add_parser("resolve-intervention")
    resolve.add_argument("task_id", type=nonblank_text)
    resolve.add_argument("--evidence", required=True, type=nonblank_text)

    reset_observation = sub.add_parser("reset-observation")
    reset_observation.add_argument("task_id", type=nonblank_text)
    reset_observation.add_argument("--operator", required=True, type=nonblank_text)
    reset_observation.add_argument("--evidence", required=True, type=nonblank_text)

    drop = sub.add_parser("drop")
    drop.add_argument("task_id", type=nonblank_text)
    drop.add_argument("--reason", required=True, type=nonblank_text)

    configure = sub.add_parser("configure")
    configure.add_argument("--automation-id")
    configure.add_argument("--cadence-minutes", type=int, choices=[1, 10, 20])

    alert = sub.add_parser("alert")
    alert_sub = alert.add_subparsers(dest="alert_action", required=True)
    alert_sub.add_parser("show")
    acquire = alert_sub.add_parser("acquire")
    acquire.add_argument("--task-id", required=True, type=nonblank_text)
    acquire.add_argument("--question", required=True, type=nonblank_text)
    acquire.add_argument("--alert-route", required=True, type=nonblank_text)
    acquire.add_argument("--operator-contacted", action="store_true")
    acquire.add_argument("--contact-receipt", type=nonblank_text)
    acquire.add_argument("--intervention-detected-at")
    release = alert_sub.add_parser("release")
    release.add_argument("--task-id", required=True, type=nonblank_text)
    release.add_argument("--question", required=True, type=nonblank_text)
    release.add_argument("--resolution", required=True, type=nonblank_text)
    release.add_argument("--route-receipt", required=True, type=nonblank_text)
    cancel_open = alert_sub.add_parser("cancel-open")
    cancel_open.add_argument("--task-id", required=True, type=nonblank_text)
    cancel_open.add_argument("--question", required=True, type=nonblank_text)
    cancel_open.add_argument("--evidence", required=True, type=nonblank_text)
    cancel = alert_sub.add_parser("cancel")
    cancel.add_argument("--task-id", required=True, type=nonblank_text)
    cancel.add_argument("--question", type=nonblank_text)

    close = sub.add_parser("close-tick")
    close.add_argument("--tick-id", required=True, type=nonblank_text)
    close.add_argument("--examined", action="append", default=[], type=nonblank_text)
    close.add_argument("--list-calls", type=int, default=0)
    close.add_argument("--tail-turns", type=int, default=0)
    close.add_argument("--artifact-checks", type=int, default=0)
    close.add_argument("--messages-sent", type=int, default=0)
    close.add_argument("--shell-checks", type=int, default=0)
    close.add_argument("--exact-cost-dollars", type=float)
    close.add_argument("--exact-input-tokens", type=int)
    close.add_argument("--exact-output-tokens", type=int)
    close.add_argument("--quiet", action="store_true")
    close.add_argument("--note")

    sub.add_parser("show")
    return result


def main() -> None:
    args = parser().parse_args()
    root = state_root(args.root)
    commands = {
        "init": cmd_init,
        "set-deliverable": cmd_set_deliverable,
        "record-tick": cmd_record_tick,
        "mark-nudge": cmd_mark_nudge,
        "resolve-intervention": cmd_resolve_intervention,
        "reset-observation": cmd_reset_observation,
        "drop": cmd_drop,
        "configure": cmd_configure,
        "alert": cmd_alert,
        "close-tick": cmd_close_tick,
        "show": cmd_show,
    }
    with interprocess_lock(root / ".state.lck"):
        commands[args.command](args, root)


if __name__ == "__main__":
    main()
