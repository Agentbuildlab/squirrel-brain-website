# Rules and scars

Use this reference to prevent locally reasonable silence from becoming fleet-wide failure.

## Rule definitions

When rules overlap, choose one primary in this order: R5, R2, R4, R3, R1. Use R6 only when the operator-only decision is the sole route to progress; otherwise choose the applicable R1-R5 and add R8. R7 and R8 are riders, never primaries.

### R1 - Stalled

Trigger when a task's turn ended and verified actionable work exists. Do not wait for elapsed time. Before nudging, check that it did not merely pause for an operator design decision, that it is not already doing the proposed item, and that the instruction will not drop unfinished work.

A question blocks one item, not the queue. Move the task to other work and add R8. A low-context handoff that needs a fresh task is operator-blocked and adds R8. Operator presence affects whether to alert the operator, never whether to nudge a stopped task.

### R2 - False block

Trigger only after an artifact proves the awaited event completed: CI concluded, a subtask returned, a build exists, or the dependency task advanced. Cite the evidence in the nudge.

### R3 - Idle while waiting

This is the most important rule. A task blocked on one item must continue with other actionable work. Grep its configured queue, filter blocked/deferred/operator items, and quote up to five unchecked results with line numbers. Legitimate idle requires either zero actionable results, recorded as a checkable count, or insufficient context for safety-critical work, which requires a fresh task and R8.

### R4 - Churn

Trigger after at least two ticks of heavy activity without a commit or other deliverable artifact while findings expand. Also trigger when the same check/theory/fix repeats, two attempts return the same error class, a supposed problem cannot be reproduced, cleared work is repeatedly re-audited, or activity drifts away from the one deliverable. Say: `Stop finding. Land what is cleared. Put new findings in the queue, not this turn.`

After two same-class failures or duplicate checks, forbid a third variation of the same approach. Require one of three outcomes: reproduce the problem with a positive artifact; change mechanism or layer; or park the concern as unverified and return to the landing. A third repetition, a second failed strategy, continuing scope drift, or no defensible next action adds R8 so the operator can choose whether to park, restart with fresh context, or change direction.

Do not accept repeated model suspicion as a defect. Require a failing test, device/UI reproduction, concrete log/error, artifact mismatch, or independently verified state. Record each candidate's direction as aligned, drifting, or unknown relative to its stored deliverable.

### R5 - Last mile

Prioritize work stranded at any delivery boundary: complete changes left uncommitted; commits left only on the machine; a pushed branch without a PR; a green PR left open; merged work without a build/release; or a shipped build without device proof. Prove the exact boundary with `git status`, upstream/ahead state, remote branch and PR lookup, full hosted checks, and build/release artifacts. “Ready” prose is not proof.

A dirty tree is not automatic push authority. Preserve unrelated or unfinished work and require the owning task to run the repository's required tests plus independent/regression review first. Once the deliverable is green, routine shipping needs no operator review: direct the same owner to commit, push, create/update the PR, wait for all required hosted checks, merge, use the authorized release/build lane, and tell the operator when it is actually ready on the phone for testing. The supervisor verifies and nudges this chain; it never performs project writes itself. Merged is not on the operator's phone. Code proof and device/production proof are different states.

### R6 - Operator-only

Do not nudge for decisions involving money charged to the operator, personal information, an irreversible direction change, or a true 50/50 taste call. Collect and surface them as the operator inbox.

### R7 - Pre-push review rider

Once per deliverable, before push, remind the owner to run its independent reviewer and regression reviewer in parallel in the same turn. Never serialize reviewers. This rides with R1-R6 and never fires alone.

### R8 - Reach the operator

When the operator must intervene, hold a global one-intervention lock. Detect the need from behavior and artifacts, not keywords: explicit decisions, repeated strategy failure, context exhaustion, ownership conflict, unsafe ambiguity, or no defensible next action may all qualify. Ordinary idle work with a safe queue item does not.

Surface a specific question and options in the owning task first. Switch to one-minute heartbeats and ring after five unanswered minutes if artifact/tail evidence still proves the intervention live. Every call names the task, explains the verified impasse and consequences, gives numbered options, and recommends one. Poll the Squirrel Brain Portal until the new answer appears, route the exact answer to the owning task, then verify artifact progress in the decided direction. The loop is not closed at call delivery or answer capture.

Queue any second intervention durably behind the lock, re-verify it each tick, and cancel it if stale. Without a real alert route, surface the question prominently and explicitly say the operator was not contacted. The supervisor owns the alert; tell the task not to duplicate it.

## Trust ledger

Count accurate, withdrawn, corrected, and pending nudges per task. A false premise resets that escalation chain. Keep the pending ledger finite; when it is full, resolve an existing nudge instead of silently discarding proof. Two withdrawn/corrected nudges place the task in observation-only mode because its repository context has proved better. Only the operator may reset that state, using nonblank evidence so the counters and reset history remain auditable.

## Known failure scars

1. **Seven-hour sleep:** three individually defensible silent ticks let tasks with 24 and 22 actionable queue items sleep for hours. Silence needs a hard ceiling and a queue check.
2. **Twenty-minute dead zone:** a time threshold left a stopped task with 24 items idle while the operator watched. Turn-end status is the primary trigger.
3. **Five stale-premise nudges:** stale PR ids, queue lines, and build prose were treated as current state. Verify artifacts, never written intent.
4. **Watchdog forgot state:** reasoning continued while session ledgers aged, disabling the ceiling. Update every examined ledger and audit bookkeeping every tick.
5. **Incomplete view claimed absence:** mixed subtask transcripts and partial CI contexts yielded confident false negatives. Require a positive control before saying something never happened.
6. **Gate-loosening temptation:** optimizing for today's merge suggested weakening a lasting protection. Never alter or propose weakening gates.
7. **Slow is not stuck:** learn normal gate duration and check live status before calling a wait false.
8. **Device beats review:** a user found a button bug in seconds after four reviews and 10,241 passing tests. Treat code verification and device proof as separate states.
9. **The self-invented problem loop:** repeated review can turn an observation into a blocker without reproduction, then spend hours “fixing” it through six variants. Two same-class failures trip the circuit-breaker; unproved concerns are parked, not allowed to consume the delivery.
10. **The forgotten local branch:** finished work sat uncommitted or unpushed for days because “the code is ready” was mistaken for delivery. Every delivery boundary needs an artifact receipt and an owner instruction to cross the next one.

## Scaling and stop semantics

For 3-4 tasks, inspect every stopped candidate. For 6-8, keep one cheap fleet sweep, batch candidate-tail reads, and omit active tails. Above 8, retain every enrolled task and process stopped candidates oldest-idle-first in batches of four. Preserve the same immediate stopped-task trigger and 30-minute ceiling; never require manual watchlist selection.

Dropping a task only removes monitoring. It does not interrupt, archive, or stop that task, and it does not stop its token spend. Use a task-management primitive only when the operator separately authorizes that action.
