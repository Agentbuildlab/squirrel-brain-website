# Platform adapters

The package is shared. The orchestration adapter is host-specific. Never duplicate the anti-churn, contact, receipt, or state rules in a second skill; map the host's supported capabilities to this one core.

## Common capability probe

Before enabling recurrence, prove all five capabilities with harmless artifacts:

1. list the sessions or teammates the coordinator is allowed to supervise;
2. read only the newest bounded tail of one test owner;
3. send one test message to that exact owner and capture a delivery receipt;
4. create or update one recurring coordinator wake-up and read its ACTIVE state back;
5. run `python3 scripts/supervisor_state.py init` and the Contact Your Human read-only `probe` without exposing credentials.

If any capability is absent, fail closed and name it. Do not claim that fleet supervision or phone escalation is active merely because the skill directory exists.

## Codex Desktop

Install the package under `${CODEX_HOME:-$HOME/.codex}/skills`. Use the Codex task list, bounded task read, task messaging, and heartbeat automation tools. The dedicated projectless Supervisor Loop task owns the heartbeat and state; watched project tasks keep ownership of their code and release work. The helpers default to `${CODEX_HOME:-$HOME/.codex}/supervisor-loop-state` and `${CODEX_HOME:-$HOME/.codex}/contact-human-state`.

## Claude Code

Install the same package under `${CLAUDE_CONFIG_DIR:-$HOME/.claude}/skills`. Claude Code discovers personal skills from `~/.claude/skills/<skill-name>/SKILL.md` and can load additions without restarting when the top-level skills directory already exists.

For one Claude Code session, the skill may supervise only work visible to that session. Fleet supervision across independent workers requires a proved coordination surface. Claude Code Agent Teams provide a shared task list and direct teammate messaging, but they are experimental, disabled by default, and have resume/status limitations. Do not enable them silently or call them production-ready. When the operator enables Agent Teams, use the team lead as the coordinator and map shared tasks, teammate status, and `SendMessage` to the common probe. Never pre-author or edit Claude's generated team runtime files.

Keep Claude's state isolated. Set `SUPERVISOR_LOOP_STATE_ROOT=${CLAUDE_CONFIG_DIR:-$HOME/.claude}/supervisor-loop-state` and `CONTACT_HUMAN_STATE_ROOT=${CLAUDE_CONFIG_DIR:-$HOME/.claude}/contact-human-state` in the authorized Claude environment or prefix every helper invocation with those values. When `CLAUDE_CONFIG_DIR` is present and `CODEX_HOME` is absent, both helpers select the Claude tree automatically. Explicit state-root variables win when both hosts share a shell.

Claude Code hooks are lifecycle triggers, not a persistent 20/60-minute timer. A Claude installation therefore also needs an already-authorized persistent driver that wakes the dedicated coordinator. Prove that driver separately; if it is absent, the skill remains installable but unattended recurrence is not active.

## Other agents

Any agent may use the same package when it can provide the common five capabilities. Keep credentials in that host's secret store or operating-system Keychain. Do not add personal names, API keys, device identifiers, account identifiers, transcript contents, or machine-specific paths to the shared package.
