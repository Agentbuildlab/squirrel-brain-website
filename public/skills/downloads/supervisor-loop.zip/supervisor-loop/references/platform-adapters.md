# Platform adapters

The package is shared. The orchestration adapter is host-specific. Never duplicate the anti-churn, contact, receipt, or state rules in a second skill; map the host's supported capabilities to this one core.

## Common capability probe

Before enabling recurrence, prove all five capabilities with harmless artifacts:

1. list the sessions or teammates the coordinator is allowed to supervise;
2. read only the newest bounded tail of one test owner;
3. send one test message to that exact owner and capture a delivery receipt;
4. create or update one recurring coordinator wake-up and read its ACTIVE state back;
5. run `python3 scripts/supervisor_state.py init` and the Contact Your Human read-only `probe` without exposing credentials.

If any capability is absent, fail closed and name it. Do not claim that fleet supervision or phone escalation is active merely because the skill directory exists.

## Codex Desktop

Install the package under `${CODEX_HOME:-$HOME/.codex}/skills`. Use the Codex task list, bounded task read, task messaging, and heartbeat automation tools. The dedicated projectless Supervisor Loop task owns the heartbeat and state; watched project tasks keep ownership of their code and release work. The helpers default to `${CODEX_HOME:-$HOME/.codex}/supervisor-loop-state` and `${CODEX_HOME:-$HOME/.codex}/contact-human-state`.

## Claude Code

Install the same package under `${CLAUDE_CONFIG_DIR:-$HOME/.claude}/skills`. Claude Code discovers personal skills from `~/.claude/skills/<skill-name>/SKILL.md` and can load additions without restarting when the top-level skills directory already exists.

Claude Code Desktop builds that expose `mcp__ccd_session_mgmt__*` satisfy discovery, bounded reads, and task messaging directly. Agent Teams are not required. Map the common probe as follows:

- list sessions with `mcp__ccd_session_mgmt__list_sessions`; use `sessionId`, `title`, `isRunning`, `lastActivityAt`, and associated `prNumber`/`prState` only as bounded discovery metadata;
- read the newest bounded tail with `mcp__ccd_session_mgmt__list_events` and an explicit limit;
- send the nudge to the exact owner with `mcp__ccd_session_mgmt__send_message`; it arrives as a user turn labelled `From <sender title>`;
- run the state helper and Contact probe through the ordinary shell exactly as documented.

Keep the coordinator as an ordinary interactive session. Session messaging is unavailable from scheduled-task or remote sessions and cannot deliver to those sessions. Exclude those sessions from the supervised fleet: a cloud or unattended scheduled-task coordinator cannot nudge, so do not claim fleet supervision from one.

Keep Claude's state isolated. Set `SUPERVISOR_LOOP_STATE_ROOT=${CLAUDE_CONFIG_DIR:-$HOME/.claude}/supervisor-loop-state` and `CONTACT_HUMAN_STATE_ROOT=${CLAUDE_CONFIG_DIR:-$HOME/.claude}/contact-human-state` in the authorized Claude environment or prefix every helper invocation with those values. When `CLAUDE_CONFIG_DIR` is present and `CODEX_HOME` is absent, both helpers select the Claude tree automatically. Explicit state-root variables win when both hosts share a shell.

Use `CronCreate` in that interactive coordinator for the heartbeat. It accepts a five-field cron expression in local time; start with `*/20 * * * *` running `/supervisor-loop`. The job is session-scoped, auto-expires after seven days, and fires only while Claude Code is running and the REPL is idle. Missed fires do not catch up. Starting a fresh conversation clears the job, while `--resume` or `--continue` restores an unexpired job from that same session.

Persist each `CronCreate` receipt's job ID and creation time in host-adapter state; derive `renew_at` at six days and `expires_at` at seven days. Before creating, resuming, changing cadence, or renewing recurrence, use `CronList`. Reuse only when exactly one matching `/supervisor-loop` job exists, its ID and cadence match the stored receipt, and renewal is not due.

For a missing or stale job, wrong cadence, same-cadence renewal due, receipt mismatch, or duplicate matches, use `CronDelete` on every matching Supervisor job before `CronCreate` exactly one replacement and persist its new receipt. Do not create when cleanup fails. This delete-before-create rule prevents a resumed coordinator or renewal from stacking heartbeats. If no exact active job exists after repair, the skill remains installed but unattended recurrence is not active.

Keep host-specific doctrine in a separate Claude wrapper `SKILL.md` when needed, and vendor this package's `scripts/` and `references/` beneath it rather than duplicating the portable rules. The Supervisor Loop and Contact Your Human packages may coexist under the same skills root.

## Other agents

Any agent may use the same package when it can provide the common five capabilities. Keep credentials in that host's secret store or operating-system Keychain. Do not add personal names, API keys, device identifiers, account identifiers, transcript contents, or machine-specific paths to the shared package.
