#!/usr/bin/env python3
"""Secure Squirrel Brain phone escalation with Portal reply correlation."""

from __future__ import annotations

import argparse
import fcntl
import json
import os
import re
import subprocess
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from contextlib import contextmanager
from pathlib import Path
from typing import Any

DEFAULT_URL = "https://geczbtsjfbvfukdzdemr.supabase.co/functions/v1/mcp-server"
DEFAULT_STATE = Path(os.environ.get("CODEX_HOME", str(Path.home() / ".codex"))) / "contact-human-state/state.json"
STATE_MARKER = ".contact-human-state-root"
STATE_MARKER_VALUE = "contact-human-state-v1\n"
MAX_BRIEFING_CHARS = 1900
UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$", re.IGNORECASE)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, file_pointer, code, message, headers, new_url):
        return None


def timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def required_text(value: str, label: str) -> str:
    normalized = str(value).strip()
    if not normalized:
        raise ValueError(f"{label} must contain non-whitespace text")
    return normalized


def nonblank_arg(value: str) -> str:
    try:
        return required_text(value, "value")
    except ValueError as error:
        raise argparse.ArgumentTypeError(str(error)) from error


def keychain(service: str) -> str | None:
    try:
        result = subprocess.run(
            ["security", "find-generic-password", "-s", service, "-a", "contact-human", "-w"],
            check=False, capture_output=True, text=True, timeout=5,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    return result.stdout.strip() if result.returncode == 0 else None


def credentials() -> tuple[str, str]:
    private = os.environ.get("SB_API_KEY") or keychain("Squirrel Brain MCP")
    public = os.environ.get("SB_ANON_JWT") or keychain("Squirrel Brain MCP Anon")
    if not private or not public:
        raise RuntimeError("Squirrel Brain credentials unavailable. The human was NOT contacted.")
    return private, public


def endpoint() -> str:
    value = os.environ.get("SB_MCP_URL", DEFAULT_URL)
    parsed = urllib.parse.urlparse(value)
    trusted = {DEFAULT_URL, *filter(None, (item.strip() for item in os.environ.get("SB_MCP_TRUSTED_URLS", "").split(",")))}
    if (parsed.scheme != "https" or parsed.username or parsed.password or parsed.query or parsed.fragment
            or value.rstrip("/") not in {item.rstrip("/") for item in trusted}):
        raise RuntimeError("SB_MCP_URL is not an explicitly trusted HTTPS MCP endpoint")
    return value


def call_tool(name: str, arguments: dict[str, Any], caller: str) -> dict[str, Any]:
    url = endpoint()  # Validate the destination before loading either credential.
    private, public = credentials()
    body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "tools/call",
                       "params": {"name": name, "arguments": arguments}}).encode()
    request = urllib.request.Request(url, data=body, method="POST", headers={
        "Content-Type": "application/json", "X-API-Key": private,
        "Authorization": f"Bearer {public}", "X-Agent-Name": caller,
    })
    try:
        with urllib.request.build_opener(NoRedirect).open(request, timeout=45) as response:
            outer = json.loads(response.read())
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as error:
        raise RuntimeError(f"Squirrel Brain request failed; delivery outcome is unknown: {error}") from error
    if outer.get("error"):
        raise RuntimeError(f"Squirrel Brain rejected {name}; delivery outcome is unknown: {outer['error']}")
    result = outer.get("result", {})
    if isinstance(result, dict) and result.get("isError") is True:
        raise RuntimeError(f"Squirrel Brain rejected {name}; delivery outcome is unknown")
    blocks = result.get("content", []) if isinstance(result, dict) else []
    if blocks and isinstance(blocks[0], dict) and isinstance(blocks[0].get("text"), str):
        try:
            inner = json.loads(blocks[0]["text"])
            return inner if isinstance(inner, dict) else {"value": inner}
        except json.JSONDecodeError:
            return {"text": blocks[0]["text"]}
    return result if isinstance(result, dict) else {"value": result}


def messages(caller: str, call_id: str) -> list[dict[str, Any]]:
    result = call_tool("get_portal_messages", {
        "limit": 100, "direction": "outbound", "agent_name": "all",
        "call_id": call_id, "mark_read": False,
    }, caller)
    if "messages" not in result or not isinstance(result["messages"], list):
        raise RuntimeError("Portal message response schema is invalid; refusing to treat it as no answer")
    if not all(isinstance(item, dict) for item in result["messages"]):
        raise RuntimeError("Portal message rows are malformed; refusing to treat them as no answer")
    return result["messages"]


def state_file(args: argparse.Namespace) -> Path:
    candidate = Path(args.state_file).expanduser()
    absolute = candidate.absolute()
    current = Path(absolute.anchor)
    for part in absolute.parts[1:]:
        current = current / part
        if os.path.lexists(current) and current.is_symlink():
            if current == Path("/var") and current.resolve() == Path("/private/var"):
                continue
            raise RuntimeError("Escalation state path may not use symbolic links")
    path = candidate.resolve()
    forbidden_parents = {Path("/"), Path.home().resolve(), Path("/tmp").resolve()}
    if path.parent in forbidden_parents or path == Path("/"):
        raise RuntimeError("Escalation state must live in a dedicated private directory")
    ensure_state_root(path)
    return path


def secure_directory(path: Path) -> None:
    if path.exists():
        mode = path.stat().st_mode & 0o777
        if not path.is_dir() or path.stat().st_uid != os.getuid() or mode & 0o077:
            raise RuntimeError("Escalation state directory is not private and helper-owned")
        return
    try:
        path.mkdir(parents=True, exist_ok=False, mode=0o700)
    except FileExistsError:
        secure_directory(path)
        return
    path.chmod(0o700)


def ensure_state_root(path: Path) -> None:
    parent = path.parent
    existed = parent.exists()
    secure_directory(parent)
    marker = parent / STATE_MARKER
    entries = {item.name for item in parent.iterdir()}
    default_path = path.resolve() == DEFAULT_STATE.expanduser().resolve()
    init_lock = parent / ".contact-human-init.lock"
    allowed_legacy = {path.name, f".{path.name}.lock", init_lock.name}
    legacy_allowed = default_path and entries <= allowed_legacy
    if not marker.exists() and existed and entries and not legacy_allowed and entries != {init_lock.name}:
        raise RuntimeError("Existing escalation directory is not a contact-human-owned state root")
    lock_descriptor = os.open(init_lock, os.O_RDWR | os.O_CREAT, 0o600)
    try:
        os.fchmod(lock_descriptor, 0o600)
        fcntl.flock(lock_descriptor, fcntl.LOCK_EX)
        if marker.is_symlink():
            raise RuntimeError("Escalation state directory has an invalid ownership marker")
        if marker.exists() and marker.read_text() != STATE_MARKER_VALUE:
            raise RuntimeError("Escalation state directory has an invalid ownership marker")
        if not marker.exists():
            current_entries = {item.name for item in parent.iterdir()} - {init_lock.name}
            if current_entries and not (default_path and current_entries <= {path.name, f".{path.name}.lock"}):
                raise RuntimeError("Existing escalation directory is not a contact-human-owned state root")
            descriptor = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                handle.write(STATE_MARKER_VALUE)
                handle.flush()
                os.fsync(handle.fileno())
    finally:
        fcntl.flock(lock_descriptor, fcntl.LOCK_UN)
        os.close(lock_descriptor)


def read_state(path: Path) -> dict[str, Any]:
    ensure_state_root(path)
    if path.exists():
        path.chmod(0o600)
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as error:
        raise RuntimeError("Existing escalation state is unreadable or malformed; refusing to ring or route") from error
    if not isinstance(value, dict):
        raise RuntimeError("Existing escalation state is not an object; refusing to ring or route")
    return value


def write_state(path: Path, value: dict[str, Any]) -> None:
    ensure_state_root(path)
    if path.exists():
        path.chmod(0o600)
    descriptor, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temp = Path(temp_name)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(value, indent=2, sort_keys=True) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        temp.replace(path)
    except BaseException:
        try:
            os.close(descriptor)
        except OSError:
            pass
        temp.unlink(missing_ok=True)
        raise
    path.chmod(0o600)


@contextmanager
def state_lock(path: Path):
    ensure_state_root(path)
    lock_path = path.with_name(f".{path.name}.lock")
    descriptor = os.open(lock_path, os.O_RDWR | os.O_CREAT, 0o600)
    try:
        os.fchmod(descriptor, 0o600)
        fcntl.flock(descriptor, fcntl.LOCK_EX)
        yield
    finally:
        fcntl.flock(descriptor, fcntl.LOCK_UN)
        os.close(descriptor)


def briefing(args: argparse.Namespace) -> str:
    choices = [choice.strip() for choice in args.option if choice.strip()]
    if len(choices) < 2:
        raise ValueError("At least two concrete --option values are required")
    required_text(args.task_id, "task id")
    task_title = required_text(args.task_title, "task title")
    context = required_text(args.context, "context")
    question = required_text(args.question, "question")
    recommendation = required_text(args.recommendation, "recommendation")
    caller_name = required_text(args.caller_name, "caller name")
    salutation = f"{args.human_name.strip()}, " if args.human_name.strip() else ""
    parts = [f"{salutation}this is {caller_name} calling about {task_title}.",
             context, f"The decision is: {question}",
             "The options are " + "; ".join(f"option {i + 1}, {choice}" for i, choice in enumerate(choices)) + ".",
             f"The recommendation is {recommendation}."]
    parts.append("Please answer with the option number and any change you want.")
    value = " ".join(part for part in parts if part).replace("\n", " ")
    if len(value) > MAX_BRIEFING_CHARS:
        raise ValueError("The call briefing is too long; shorten it without removing context or options")
    return value


def first_new_reply(current: list[dict[str, Any]], call_id: str, ring_requested_at: str) -> dict[str, Any] | None:
    ring_time = parse_aware_timestamp(ring_requested_at)
    if ring_time is None:
        return None
    candidates: list[tuple[datetime, dict[str, Any]]] = []
    for item in current:
        message_id = item.get("id")
        content = item.get("content")
        created_at = parse_aware_timestamp(item.get("created_at"))
        if (item.get("direction") == "outbound"
                and isinstance(message_id, str) and bool(message_id.strip())
                and isinstance(content, str) and bool(content.strip())
                and str(item.get("call_id", "")).lower() == call_id
                and created_at is not None and created_at >= ring_time):
            candidates.append((created_at, item))
    return min(candidates, key=lambda candidate: candidate[0])[1] if candidates else None


def parse_aware_timestamp(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed.astimezone(timezone.utc) if parsed.tzinfo is not None else None


def validate_correlation_state(state: dict[str, Any]) -> tuple[str, str]:
    call_id = state.get("call_id")
    ring_requested_at = state.get("ring_requested_at")
    if not isinstance(call_id, str) or not UUID_RE.fullmatch(call_id):
        raise RuntimeError("Open escalation has no valid transport call id; refusing to guess an answer")
    if not isinstance(ring_requested_at, str):
        raise RuntimeError("Open escalation has no valid ring timestamp; refusing to guess an answer")
    if parse_aware_timestamp(ring_requested_at) is None:
        raise RuntimeError("Open escalation ring timestamp must include a timezone")
    return call_id.lower(), ring_requested_at


def probe(args: argparse.Namespace) -> None:
    call_tool("get_current_time", {}, required_text(args.caller_name, "caller name"))
    print(json.dumps({"ok": True, "route": "squirrel-brain-mcp"}))


def brief(args: argparse.Namespace) -> None:
    print(briefing(args))


def ring(args: argparse.Namespace) -> None:
    path = state_file(args)
    with state_lock(path):
        existed = path.exists()
        current = read_state(path)
        if existed and current.get("status") not in {
            "idle", "closed", "cancelled", "ring_requested", "delivery_unknown",
            "awaiting_reply", "answered", "routed", "applied", "correlation_failed",
        }:
            raise RuntimeError("Existing escalation state has no recognized status; refusing to ring")
        if current.get("status") not in {None, "idle", "closed", "cancelled"}:
            raise RuntimeError("An escalation is already open; do not ring twice")
        speech = briefing(args)
        ring_requested_at = timestamp()
        state = {
            "status": "ring_requested", "task_id": args.task_id, "task_title": args.task_title,
            "question": args.question, "briefing": speech, "caller_name": args.caller_name,
            "ring_requested_at": ring_requested_at,
        }
        write_state(path, state)
        try:
            receipt = call_tool("cell_alert", {
                "title": f"{args.caller_name}: {args.task_title[:42]}", "message": speech,
            }, args.caller_name)
        except BaseException:
            state.update({"status": "delivery_unknown", "failure": "no definitive delivery receipt returned"})
            write_state(path, state)
            raise
        reached_value = receipt.get("devices_reached")
        if isinstance(reached_value, bool) or not isinstance(reached_value, int):
            state.update({"status": "delivery_unknown", "failure": "malformed delivery receipt"})
            write_state(path, state)
            raise RuntimeError(f"Delivery receipt was malformed; delivery outcome is unknown: {receipt}")
        reached = reached_value
        if receipt.get("called") is False and reached == 0:
            state.update({"status": "idle", "failure": "delivery receipt definitively reported no call",
                          "receipt": {"called": False, "devices_reached": 0}})
            write_state(path, state)
            raise RuntimeError(f"Delivery was not proved; the human was NOT contacted: {receipt}")
        if receipt.get("called") is not True or reached < 1:
            state.update({"status": "delivery_unknown", "failure": "ambiguous delivery receipt"})
            write_state(path, state)
            raise RuntimeError(f"Delivery was ambiguous; do not ring again without evidenced cancellation: {receipt}")
        call_id = str(receipt.get("call_id", "")).lower()
        if not UUID_RE.fullmatch(call_id):
            write_state(path, {
                "status": "correlation_failed", "task_id": args.task_id,
                "task_title": args.task_title, "ring_requested_at": ring_requested_at,
                "failure": "cell_alert returned no valid transport call_id",
                "receipt": {"called": True, "devices_reached": reached,
                            "via_voip": receipt.get("via_voip"), "has_voice": receipt.get("has_voice")},
            })
            raise RuntimeError("Delivery lacked a valid transport call id; reply routing is disabled")
        reply_capable = receipt.get("reply_capable") is True and receipt.get("via_voip") is True
        if not reply_capable:
            write_state(path, {
                "status": "correlation_failed", "task_id": args.task_id,
                "task_title": args.task_title, "ring_requested_at": ring_requested_at,
                "call_id": call_id, "failure": "cell_alert did not prove a reply-capable two-way call",
                "receipt": {"called": True, "devices_reached": reached,
                            "via_voip": receipt.get("via_voip"),
                            "reply_capable": receipt.get("reply_capable"),
                            "has_voice": receipt.get("has_voice")},
            })
            raise RuntimeError("Delivery was not reply-capable; reply polling is disabled")
        state = {"status": "awaiting_reply", "task_id": args.task_id, "task_title": args.task_title,
                 "question": args.question, "briefing": speech, "caller_name": args.caller_name,
                 "ring_requested_at": ring_requested_at, "call_id": call_id, "poll_count": 0,
                 "receipt": {"called": True, "devices_reached": reached,
                             "via_voip": True, "reply_capable": True,
                             "has_voice": receipt.get("has_voice")}}
        write_state(path, state)
    print(json.dumps({"status": "awaiting_reply", "receipt": state["receipt"]}, indent=2))


def poll(args: argparse.Namespace) -> None:
    path = state_file(args)
    with state_lock(path):
        state = read_state(path)
        if state.get("status") != "awaiting_reply":
            print(json.dumps({"status": state.get("status", "idle"), "answer": state.get("answer")}))
            return
        call_id, ring_requested_at = validate_correlation_state(state)
        answer = first_new_reply(
            messages(str(state.get("caller_name") or args.caller_name), call_id),
            call_id,
            ring_requested_at,
        )
        state["poll_count"] = int(state.get("poll_count", 0)) + 1
        state["last_polled_at"] = timestamp()
        if answer:
            state["status"] = "answered"
            state["answer"] = {key: answer.get(key) for key in ("id", "content", "created_at", "agent_name", "call_id")}
            state["correlation_proof"] = {"method": "transport_call_id", "call_id_matched": True}
        write_state(path, state)
    print(json.dumps({"status": state["status"], "answer": state.get("answer")}, indent=2))


def require_owner(state: dict[str, Any], task_id: str) -> None:
    owner = required_text(task_id, "task id")
    if state.get("task_id") != owner:
        raise RuntimeError("Escalation transition does not match the owning task")


def transition(args: argparse.Namespace, expected: set[str], status: str, field: str, value: str) -> None:
    path = state_file(args)
    with state_lock(path):
        state = read_state(path)
        if state.get("status") not in expected:
            raise RuntimeError(f"Cannot mark {status} from state {state.get('status', 'idle')}")
        require_owner(state, args.task_id)
        if status == "routed":
            answer_id = required_text(args.answer_id, "answer id")
            if not isinstance(state.get("answer"), dict) or state["answer"].get("id") != answer_id:
                raise RuntimeError("Route receipt does not match the correlated Portal answer")
        state.update({"status": status, field: required_text(value, field), f"{status}_at": timestamp()})
        write_state(path, state)
    print(json.dumps({"status": status}))


def status(args: argparse.Namespace) -> None:
    print(json.dumps(read_state(state_file(args)), indent=2, sort_keys=True))


def clear(args: argparse.Namespace) -> None:
    path = state_file(args)
    with state_lock(path):
        state = read_state(path)
        if state.get("status") != "applied":
            raise RuntimeError(f"Cannot clear from state {state.get('status', 'idle')}; apply or explicitly cancel first")
        require_owner(state, args.task_id)
        state.update({"status": "closed", "closed_at": timestamp()})
        write_state(path, state)
    print(json.dumps({"status": "closed"}))


def cancel(args: argparse.Namespace) -> None:
    path = state_file(args)
    with state_lock(path):
        state = read_state(path)
        if state.get("status") not in {"ring_requested", "delivery_unknown", "awaiting_reply", "answered", "routed", "correlation_failed"}:
            raise RuntimeError(f"Cannot cancel from state {state.get('status', 'idle')}")
        require_owner(state, args.task_id)
        state.update({"status": "cancelled", "cancelled_at": timestamp(),
                      "cancel_evidence": required_text(args.evidence, "cancel evidence")})
        write_state(path, state)
    print(json.dumps({"status": "cancelled"}))


def add_briefing(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--task-id", required=True, type=nonblank_arg)
    parser.add_argument("--task-title", required=True, type=nonblank_arg)
    parser.add_argument("--context", required=True, type=nonblank_arg)
    parser.add_argument("--question", required=True, type=nonblank_arg)
    parser.add_argument("--option", action="append", default=[], type=nonblank_arg)
    parser.add_argument("--recommendation", required=True, type=nonblank_arg)
    parser.add_argument("--human-name", default=os.environ.get("CONTACT_HUMAN_NAME", ""))


def build_parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser()
    result.add_argument("--state-file", default=str(DEFAULT_STATE))
    result.add_argument("--caller-name", default=os.environ.get("CONTACT_CALLER_NAME", "Supervisor"), type=nonblank_arg)
    sub = result.add_subparsers(dest="command", required=True)
    sub.add_parser("probe")
    add_briefing(sub.add_parser("brief"))
    add_briefing(sub.add_parser("ring"))
    sub.add_parser("poll")
    routed = sub.add_parser("mark-routed")
    routed.add_argument("--task-id", required=True, type=nonblank_arg)
    routed.add_argument("--answer-id", required=True, type=nonblank_arg)
    routed.add_argument("--route-receipt", required=True, type=nonblank_arg)
    applied = sub.add_parser("mark-applied")
    applied.add_argument("--task-id", required=True, type=nonblank_arg)
    applied.add_argument("--evidence", required=True, type=nonblank_arg)
    sub.add_parser("status")
    cleared = sub.add_parser("clear")
    cleared.add_argument("--task-id", required=True, type=nonblank_arg)
    cancelled = sub.add_parser("cancel")
    cancelled.add_argument("--task-id", required=True, type=nonblank_arg)
    cancelled.add_argument("--evidence", required=True, type=nonblank_arg)
    return result


def main() -> None:
    args = build_parser().parse_args()
    try:
        if args.command == "probe": probe(args)
        elif args.command == "brief": brief(args)
        elif args.command == "ring": ring(args)
        elif args.command == "poll": poll(args)
        elif args.command == "mark-routed": transition(args, {"answered"}, "routed", "route_receipt", args.route_receipt)
        elif args.command == "mark-applied": transition(args, {"routed"}, "applied", "application_evidence", args.evidence)
        elif args.command == "status": status(args)
        elif args.command == "cancel": cancel(args)
        else: clear(args)
    except (RuntimeError, ValueError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(3)


if __name__ == "__main__":
    main()
